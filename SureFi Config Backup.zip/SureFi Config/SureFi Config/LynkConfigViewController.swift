//
//  LynkConfigViewController.swift
//  SureFi Config
//
//  Created by John Robinson on 11/21/16.
//  Copyright © 2016 Sure-Fi. All rights reserved.
//

import UIKit
import CoreBluetooth

class LynkConfigViewController: UIViewController , CBCentralManagerDelegate, CBPeripheralDelegate {
    
    @IBOutlet var dispView: UIView!
    @IBOutlet var progressIndicator: UIProgressView!
    @IBOutlet var doneButton: UIButton!
    
    @IBOutlet var centralConnectedLabel: UILabel!
    @IBOutlet var centralUpdatingLabel: UILabel!
    @IBOutlet var centralConfigLabel: UILabel!
    
    @IBOutlet var remoteConnectedLabel: UILabel!
    @IBOutlet var remoteUpdatingLabel: UILabel!
    @IBOutlet var remoteConfigLabel: UILabel!
    
    @IBOutlet var registerSystemLabel: UILabel!
    
    @IBOutlet var timeEstimateLabel: UILabel!
    
    var centralManager: CBCentralManager!
    var peripherals: Array<CBPeripheral> = Array<CBPeripheral>()
    var centralPeripheral: CBPeripheral!
    var remotePeripheral: CBPeripheral!
    var surefiDevices: Array<CBPeripheral> = Array<CBPeripheral>()
    var bluetoothDeviceViewController: BluetoothDeviceViewController!
    
    
    var redCharactericCentral: CBCharacteristic!
    var greenCharactericCentral: CBCharacteristic!
    var blueCharactericCentral: CBCharacteristic!
    
    var redCharactericRemote: CBCharacteristic!
    var greenCharactericRemote: CBCharacteristic!
    var blueCharactericRemote: CBCharacteristic!
    
    
    var remoteFirmwareCharacteristic: CBCharacteristic!
    var centralFirmwareCharacteristic: CBCharacteristic!
    
    var remoteCommandCharacteristic: CBCharacteristic!
    var centralCommandCharacteristic: CBCharacteristic!
    
    let BEAN_SERVICE_UUID       = CBUUID(string: "a495ff20-c5b1-4b44-b512-1370f02d74de")
    let BEAN_SCRATCH_UUIDR      = CBUUID(string: "a495ff21-c5b1-4b44-b512-1370f02d74de")
    let BEAN_SCRATCH_UUIDG      = CBUUID(string: "a495ff22-c5b1-4b44-b512-1370f02d74de")
    let BEAN_SCRATCH_UUIDB      = CBUUID(string: "a495ff23-c5b1-4b44-b512-1370f02d74de")
    let BEAN_SCRATCH_UUIDFIRM   = CBUUID(string: "a495ff24-c5b1-4b44-b512-1370f02d74de")
    let BEAN_SCRATCH_UUIDCMD    = CBUUID(string: "a495ff25-c5b1-4b44-b512-1370f02d74de")
    
    var remoteFirmwareFileData: NSData?
    var centralFirmwareFileData: NSData?
    
    var centralDeviceID: String?
    var centralDevicePeripheral: String?
    var remoteDeviceID: String?
    var remoteDevicePeripheral: String?
    var customerID: String?
    var zipCode: String?
    var systemName: String?
    
    var centralCompleted: Bool = false
    var centralConnected: Bool = false
    var centralConfiged: Bool = false
    
    var remoteCompleted: Bool = false
    var remoteConnected: Bool = false
    var remoteConfiged: Bool = false
    
    var centralReady: Bool = true
    var remoteReady: Bool = true
    
    var systemRegistered: Bool = false
    
    var centralFirmwarePage: Int = 0
    var remoteFirmwarePage: Int = 0
    
    var estimateTimer: Int = 0
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.setHidesBackButton(true, animated: false)
        
        navigationItem.title = "Configuring Sure-Fi Lynk"
       
        dispView.layer.cornerRadius = 10
        
        let centralFirmwareFilepath = "http://admin.sure-fi.com/downloads/lynk_central.fm"
        let remoteFirmwareFilepath = "http://admin.sure-fi.com/downloads/lynk_remote.fm"
        
        if let url = URL(string: centralFirmwareFilepath) {
            centralFirmwareFileData = NSData(contentsOf: url)
        } else {
            let alert: UIAlertController = UIAlertController(title: "Download Error", message: "Error Downloading Central Firmware File", preferredStyle: UIAlertControllerStyle.alert);
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil));
            self.present(alert,animated: true, completion: nil);
            navigationController?.popViewController(animated: true)
        }
        if let url = URL(string: remoteFirmwareFilepath) {
            remoteFirmwareFileData = NSData(contentsOf: url)
        } else {
            let alert: UIAlertController = UIAlertController(title: "Download Error", message: "Error Downloading Remote Firmware File", preferredStyle: UIAlertControllerStyle.alert);
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil));
            self.present(alert,animated: true, completion: nil);
            navigationController?.popViewController(animated: true)
        }
        centralManager = CBCentralManager(delegate: self, queue: nil)
        
        var timer = Timer.scheduledTimer(timeInterval: 0.05, target: self, selector: #selector(prepareSetup), userInfo: nil, repeats: true);
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func dispTimeEstimate (recordIndex: Int, recordCount: Int) {
        let currentTime = Int(NSDate().timeIntervalSince1970)
        let elapsedTime = currentTime-estimateTimer
        
        if elapsedTime > 0 && recordIndex%10 == 0 {
            let estimatedTime = ( ( elapsedTime * recordCount ) / recordIndex ) - elapsedTime
            timeEstimateLabel.text = "Estimating \(estimatedTime) Seconds Remaining"
        }
    }
    
    func prepareSetup (timer: Timer) {
        
        let centralSize = centralFirmwareFileData?.length
        let remoteSize  = remoteFirmwareFileData?.length
        let centralFirmwarePageCount = (centralFirmwareFileData?.length)!/20
        let remoteFirmwarePageCount = (remoteFirmwareFileData?.length)!/20
        
        if(centralPeripheral != nil && remotePeripheral != nil && centralSize! > 0 && remoteSize! > 0) {
            
            if(systemRegistered == false) {
                registerSystemLabel.text = "↺"
                registerSystemLabel.textColor = UIColor.darkGray

                appDelegate.userKey = "12345678-1234-XXXX-XXXX-0123456789AB";
                
                let timestamp = Int(NSDate().timeIntervalSince1970)
                let timestampstring = String(format:"%2X", timestamp)
                let sessionKey = String("12345678\(timestampstring)".characters.reversed())
                
                appDelegate.sessionKey = sessionKey
                
                let results : NSMutableDictionary = Util().getServerRequest(action: "register_lynk_system", apiData: "\(centralDeviceID!)/\(centralDevicePeripheral!)/\(remoteDeviceID!)/\(remoteDevicePeripheral!)/\(customerID!)/\(systemName!.toBase64().replacingOccurrences(of: "=", with: ""))/\(zipCode!)")
                if results["status"] as! String == "success" {
                
                    systemRegistered = true
                    registerSystemLabel.text = "✓"
                    registerSystemLabel.textColor = UIColor.green
                 }
                else if results["status"] as! String == "failure" {
                    let apiMessage = results["message"] as! String
                    let alert = UIAlertController(title: "Configuration Error", message: apiMessage, preferredStyle: .alert)
                    let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alert.addAction(ok)
                    timer.invalidate()
                    self.present(alert, animated: true, completion: nil)
                    self.navigationItem.setHidesBackButton(false, animated: false)
                }
            }
            else if(centralConnected == false) {
                centralManager.connect(centralPeripheral, options: nil)
                estimateTimer = Int(NSDate().timeIntervalSince1970)
            }
            else if(centralCompleted == false) {
                
                if centralFirmwareCharacteristic != nil && centralReady == true {
                    
                    progressIndicator.isHidden = false
                    centralUpdatingLabel.text = "↺"
                    centralUpdatingLabel.textColor = UIColor.darkGray
                    
                    if(centralFirmwarePageCount >= centralFirmwarePage)
                    {
                        let blockStart = centralFirmwarePage*20
                        var blockLength = 20
                        if ((blockStart + blockLength) > centralSize!) {
                            blockLength = centralSize! - blockStart
                        }
                        let blockRange = NSMakeRange(blockStart, blockLength)

                        let firmwarePageData = centralFirmwareFileData?.subdata(with: blockRange) as! NSData
                        centralPeripheral.writeValue(firmwarePageData as Data, for: centralFirmwareCharacteristic, type: CBCharacteristicWriteType.withoutResponse)
                        
                        if(centralFirmwarePage%32 == 0) {
                            centralReady = false
                        }
                        centralFirmwarePage += 1
                        dispTimeEstimate(recordIndex: centralFirmwarePage, recordCount: centralFirmwarePageCount)
                        let position: Float = Float(centralFirmwarePage) / Float(centralFirmwarePageCount)
                        progressIndicator.setProgress(position, animated: true)
                    }
                    else {
                        progressIndicator.isHidden = true
                        centralUpdatingLabel.text = "✓"
                        centralUpdatingLabel.textColor = UIColor.green
                        centralCompleted = true
                    }
                }
            }
            else if(centralConfiged == false) {
                centralConfigLabel.text = "↺"
                centralConfigLabel.textColor = UIColor.darkGray

                let data: [UInt8] = [0x01]
                centralPeripheral.writeValue(Data(bytes:data), for: centralCommandCharacteristic, type: CBCharacteristicWriteType.withResponse)
                
                centralConfigLabel.text = "✓"
                centralConfigLabel.textColor = UIColor.green
                centralConfiged = true
            }
            else if(remoteConnected == false) {
                centralManager.connect(remotePeripheral, options: nil)
            }
            else if(remoteCompleted == false) {
                
                if remoteFirmwareCharacteristic != nil && remoteReady == true {
 
                    progressIndicator.isHidden = false
                    remoteUpdatingLabel.text = "↺"
                    remoteUpdatingLabel.textColor = UIColor.darkGray
                    
                    if(remoteFirmwarePageCount >= remoteFirmwarePage)
                    {
                        let blockStart = remoteFirmwarePage*20
                        var blockLength = 20
                        if ((blockStart + blockLength) > remoteSize!) {
                            blockLength = remoteSize! - blockStart
                        }
                        let blockRange = NSMakeRange(blockStart, blockLength)
                        
                        let firmwarePageData = remoteFirmwareFileData?.subdata(with: blockRange) as! NSData
                        remotePeripheral.writeValue(firmwarePageData as Data, for: remoteFirmwareCharacteristic, type: CBCharacteristicWriteType.withoutResponse)
                        
                        if(remoteFirmwarePage%32 == 0) {
                            remoteReady = false
                        }
                        remoteFirmwarePage += 1
                        dispTimeEstimate(recordIndex: remoteFirmwarePage, recordCount: remoteFirmwarePageCount)
                        let position: Float = Float(remoteFirmwarePage) / Float(remoteFirmwarePageCount)
                        progressIndicator.setProgress(position, animated: true)
                    }
                    else if remoteFirmwareCharacteristic != nil {
                        progressIndicator.isHidden = true
                        remoteUpdatingLabel.text = "✓"
                        remoteUpdatingLabel.textColor = UIColor.green
                        remoteCompleted = true
                    }
                }
            }
            else if(remoteConfiged == false) {
                remoteConfigLabel.text = "↺"
                remoteConfigLabel.textColor = UIColor.darkGray
                
                let data: [UInt8] = [0x02]
                remotePeripheral.writeValue(Data(bytes:data), for: remoteCommandCharacteristic, type: CBCharacteristicWriteType.withResponse)
                
                remoteConfigLabel.text = "✓"
                remoteConfigLabel.textColor = UIColor.green
                remoteConfiged = true
            }
            else {
                doneButton.isHidden = false
                timer.invalidate()
            }
        }
        
        
    }
    
    func centralManagerDidUpdateState(_ central: CBCentralManager)
    {
        if (central.state == CBManagerState.poweredOn)
        {
            self.centralManager!.scanForPeripherals(withServices: nil, options: nil)
        }
        else
        {
            let alert: UIAlertController = UIAlertController(title: "Bluetooth Error", message: "Bluetooth is not turned on.", preferredStyle: UIAlertControllerStyle.alert);
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil));
            self.present(alert,animated: true, completion: nil);
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber)
    {
        let name = peripheral.name;
        if(name?.uppercased().range(of: "BEAN") != nil || name?.uppercased().range(of: "SUREFI") != nil) {
            if(!surefiDevices.contains(peripheral)) {
                
                if(peripheral.identifier.uuidString == centralDeviceID) {
                    centralPeripheral = peripheral
                    centralPeripheral.delegate = self
                }
                if(peripheral.identifier.uuidString == remoteDeviceID) {
                    remotePeripheral = peripheral
                    remotePeripheral.delegate = self
                }
                surefiDevices.append(peripheral);
            }
        }
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        if peripheral == centralPeripheral {
            centralConnectedLabel.text = "✓"
            centralConnectedLabel.textColor = UIColor.green
            centralConnected = true
            centralPeripheral.discoverServices(nil)
        }
        if peripheral == remotePeripheral {
            remoteConnectedLabel.text = "✓"
            remoteConnectedLabel.textColor = UIColor.green
            remoteConnected = true
            remotePeripheral.discoverServices(nil)
        }
        
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        for service in peripheral.services! {
            let thisService = service as CBService
            
            if service.uuid == BEAN_SERVICE_UUID {
                peripheral.discoverCharacteristics(nil,for: thisService)
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral,didDiscoverCharacteristicsFor service: CBService,error: Error?) {
        for characteristic in service.characteristics! {
            let thisCharacteristic = characteristic as CBCharacteristic
            
            if(peripheral == centralPeripheral) {
                if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDFIRM {
                    peripheral.setNotifyValue(true,for: thisCharacteristic)
                    centralFirmwareCharacteristic = thisCharacteristic
                }
                if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDR {
                    peripheral.setNotifyValue(true,for: thisCharacteristic)
                    redCharactericCentral = thisCharacteristic
                }
                if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDG {
                    peripheral.setNotifyValue(true,for: thisCharacteristic)
                    greenCharactericCentral = thisCharacteristic
                }
                if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDB {
                    peripheral.setNotifyValue(true,for: thisCharacteristic)
                    blueCharactericCentral = thisCharacteristic
                }
                if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDCMD {
                    peripheral.setNotifyValue(true,for: thisCharacteristic)
                    centralCommandCharacteristic = thisCharacteristic
                }
            }
            if(peripheral == remotePeripheral) {
                if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDFIRM {
                    peripheral.setNotifyValue(true,for: thisCharacteristic)
                    remoteFirmwareCharacteristic = thisCharacteristic
                }
                if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDR {
                    peripheral.setNotifyValue(true,for: thisCharacteristic)
                    redCharactericRemote = thisCharacteristic
                }
                if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDG {
                    peripheral.setNotifyValue(true,for: thisCharacteristic)
                    greenCharactericRemote = thisCharacteristic
                }
                if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDB {
                    peripheral.setNotifyValue(true,for: thisCharacteristic)
                    blueCharactericRemote = thisCharacteristic
                }
                if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDCMD {
                    peripheral.setNotifyValue(true,for: thisCharacteristic)
                    remoteCommandCharacteristic = thisCharacteristic
                }
            }
        }
    }
    
    @IBAction func completeConfig (sender: UIButton) {
        let viewControllers: [UIViewController] = self.navigationController!.viewControllers as [UIViewController];
        self.navigationController!.popToViewController(viewControllers[viewControllers.count - 3], animated: true);
    }
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        
        let value = characteristic.value! as Data
        let stringValue = NSString(data: value, encoding: String.Encoding.utf8.rawValue) as? String ?? ""
        let intValue = Int(value[0])
        
        if (peripheral == centralPeripheral && characteristic==centralFirmwareCharacteristic) {
            if stringValue == "ready" {
                centralReady = true
            }
        }
        if (peripheral == remotePeripheral && characteristic==remoteFirmwareCharacteristic) {
            if stringValue == "ready" {
                remoteReady = true
            }
        }
        
        if(redCharactericCentral != nil && characteristic == redCharactericCentral) {
            print("Central Red:\(intValue)")
        }
        if(redCharactericRemote != nil && characteristic == redCharactericRemote) {
            print("Remote Red:\(intValue)")
        }
        if(greenCharactericCentral != nil && characteristic == greenCharactericCentral) {
            print("Central Green:\(intValue)")
        }
        if(greenCharactericRemote != nil && characteristic == greenCharactericRemote) {
            print("Remote Green:\(intValue)")
        }
        if(blueCharactericCentral != nil && characteristic == blueCharactericCentral) {
            print("Central Blue:\(intValue)")
        }
        if(blueCharactericRemote != nil && characteristic == blueCharactericRemote) {
            print("Remote Blue:\(intValue)")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        centralManager.cancelPeripheralConnection(centralPeripheral)
        centralManager.cancelPeripheralConnection(remotePeripheral)
        centralManager?.stopScan()
    }
    

    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
