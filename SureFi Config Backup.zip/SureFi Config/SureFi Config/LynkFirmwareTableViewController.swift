//
//  LynkFirmwareTableViewController.swift
//  SureFi Config
//
//  Created by John Robinson on 12/5/16.
//  Copyright © 2016 Sure-Fi. All rights reserved.
//

import UIKit

class LynkFirmwareTableViewController: UITableViewController {
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    var firmwareDictionary: NSMutableDictionary?
    var firmwareDirectory: URL?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backgroundImage = UIImage(named: "background");
        let backgroundImageView = UIImageView(image: backgroundImage);
        backgroundImageView.contentMode = UIViewContentMode.scaleAspectFill;
        self.tableView.backgroundView = backgroundImageView;
        
        let backItem = UIBarButtonItem()
        backItem.title = "Back"
        navigationItem.backBarButtonItem = backItem
        
        navigationItem.title = "Manage Firmware"
        
        if appDelegate.userData == nil {
            appDelegate.userKey = "12345678-1234-XXXX-XXXX-0123456789AB";
            
            let timestamp = Int(NSDate().timeIntervalSince1970)
            let timestampstring = String(format:"%2X", timestamp)
            let sessionKey = String("12345678\(timestampstring)".characters.reversed())
            
            appDelegate.sessionKey = sessionKey
        }
        
        let results : NSMutableDictionary = Util().getServerRequest(action: "get_lynk_firmware", apiData: "")
        if results["status"] != nil && results["status"] as! String == "success" {
            
            firmwareDictionary = results["data"] as! NSMutableDictionary
        }
        else if results["status"] as! String == "failure" {
            let apiMessage = results["message"] as! String
            let alert = UIAlertController(title: "Configuration Error", message: apiMessage, preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(ok)
            self.present(alert, animated: true, completion: nil)
            self.navigationItem.setHidesBackButton(false, animated: false)
        }
        
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        firmwareDirectory = documentsDirectory.appendingPathComponent("firmware")
        
        do {
            try FileManager.default.createDirectory(atPath: firmwareDirectory!.path, withIntermediateDirectories: true, attributes: nil)
        } catch let error as NSError {
            print("Error creating directory: \(error.localizedDescription)")
        }
        
        let firmwareTypes = firmwareDictionary?.allKeys
        for firmwareType in firmwareTypes! {
            
            print("FirmwareType:\(firmwareType)")
            let firmwareDirPath = firmwareDirectory!.appendingPathComponent(firmwareType as! String)
            do {
                try FileManager.default.createDirectory(atPath: firmwareDirPath.path, withIntermediateDirectories: true, attributes: nil)
            } catch let error as NSError {
                print("Error creating directory: \(error.localizedDescription)")
            }
            
            
            
            let temp = firmwareDictionary?.object(forKey: firmwareType) as? NSMutableDictionary
            if temp != nil {
                let firmwareFileStatuses = temp!.allKeys
                for firmwareFileStatus in firmwareFileStatuses {
                    
                    print("FirmwareStatus:\(firmwareFileStatus)")
                    let firmwareStatusDirPath = firmwareDirPath.appendingPathComponent(firmwareFileStatus as! String)
                    do {
                        try FileManager.default.createDirectory(atPath: firmwareStatusDirPath.path, withIntermediateDirectories: true, attributes: nil)
                    } catch let error as NSError {
                        print("Error creating directory: \(error.localizedDescription)")
                    }
                    
                    let temp2 = temp!.object(forKey: firmwareFileStatus as! String) as? NSMutableDictionary
                    if temp2 != nil {
                        let firmwareVersions = temp2!.allKeys
                        for firmwareVersion in firmwareVersions {
                            
                            print("FirmwareVersion:\(firmwareVersion)")
                            let firmwareVersionDirPath = firmwareStatusDirPath.appendingPathComponent(firmwareVersion as! String)
                            do {
                                try FileManager.default.createDirectory(atPath: firmwareVersionDirPath.path, withIntermediateDirectories: true, attributes: nil)
                            } catch let error as NSError {
                                print("Error creating directory: \(error.localizedDescription)")
                            }
                            
                            let firmwareData = temp2!.object(forKey: firmwareVersion) as! NSMutableDictionary
                            let firmwareFilePath = firmwareVersionDirPath.appendingPathComponent(firmwareData.object(forKey: "firmware_filename") as! String)
                            
                            let fileContents = firmwareFilePath.absoluteString
                            do {
                                try fileContents.write(toFile: firmwareFilePath.path, atomically: true, encoding: .utf8)
                            } catch let error as NSError {
                                print("Error creating directory: \(error.localizedDescription)")
                            }
                            
                        }
                    }
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 2
        }
        if section == 1 {
            return 4
        }
        return 0
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        if section == 0 {
            return "Lynk Firmware Files"
        }
        else if section == 1 {
            return "Lynk Peripheral Firmware Files"
        }
        return ""
    }
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let header: UITableViewHeaderFooterView = view as! UITableViewHeaderFooterView;
        header.textLabel?.textColor = UIColor.white;
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FirmwareCell", for: indexPath)
        
        let firmwareImageView: UIImageView = cell.viewWithTag(100) as! UIImageView
        let firmwareTitleLabel: UILabel = cell.viewWithTag(200) as! UILabel
        let firmwareDescLabel: UILabel = cell.viewWithTag(300) as! UILabel
        
        firmwareDescLabel.text = ""
        
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                firmwareTitleLabel.text = "Lynk Central Unit"
                firmwareImageView.image = UIImage(named: "lynk_hardware_icon")
                
                var firmwarePath = firmwareDirectory!.appendingPathComponent("lynk_central")
                var stableFirmwarePath = firmwarePath.appendingPathComponent("stable")
                var betaFirmwarePath = firmwarePath.appendingPathComponent("beta")
                
                do {
                    // Get the directory contents urls (including subfolders urls)
                    let stableDirectoryContents = try FileManager.default.contentsOfDirectory(at: stableFirmwarePath, includingPropertiesForKeys: nil, options: [])
                    let betaDirectoryContents = try FileManager.default.contentsOfDirectory(at: betaFirmwarePath, includingPropertiesForKeys: nil, options: [])
                    
                    firmwareDescLabel.text = "\(stableDirectoryContents.count) Stable"
                    if betaDirectoryContents.count > 0 {
                        firmwareDescLabel.text = "\(firmwareDescLabel.text)  and \(stableDirectoryContents.count) Beta"
                    }
                    
                    
                } catch let error as NSError {
                    print(error.localizedDescription)
                }
                print(firmwarePath)
                
            }
            if indexPath.row == 1 {
                firmwareTitleLabel.text = "Lynk Remote Unit"
                firmwareImageView.image = UIImage(named: "lynk_hardware_icon")
            }
        }
        
        if indexPath.section == 1 {
            if indexPath.row == 0 {
                firmwareTitleLabel.text = "Wiegand Door - Central"
                firmwareImageView.image = UIImage(named: "peripheal_5_icon")
            }
            if indexPath.row == 1 {
                firmwareTitleLabel.text = "Wiegand Door - Remote"
                firmwareImageView.image = UIImage(named: "peripheal_5_icon")
            }
            if indexPath.row == 2 {
                firmwareTitleLabel.text = "USB Extender - Central"
                firmwareImageView.image = UIImage(named: "peripheal_6_icon")
            }
            if indexPath.row == 3 {
                firmwareTitleLabel.text = "USB Extender - Remote"
                firmwareImageView.image = UIImage(named: "peripheal_6_icon")
            }
        }
        
        // Configure the cell...
        
        return cell
    }
    
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
