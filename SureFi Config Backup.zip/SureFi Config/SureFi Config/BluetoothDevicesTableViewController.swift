//
//  BluetoothDevicesTableViewController.swift
//  SureFi Config
//
//  Created by John Robinson on 10/19/16.
//  Copyright © 2016 Sure-Fi. All rights reserved.
//

import CoreBluetooth
import UIKit

class BluetoothDevicesTableViewController: UITableViewController , CBCentralManagerDelegate, CBPeripheralDelegate {
    
    var centralManager: CBCentralManager!
    var peripherals: Array<CBPeripheral> = Array<CBPeripheral>()
    var connectedPeripheral: CBPeripheral!
    var surefiDevices: Array<CBPeripheral> = Array<CBPeripheral>()
    var bluetoothDeviceViewController: BluetoothDeviceViewController!
    var redCharacteric: CBCharacteristic!
    var greenCharacteric: CBCharacteristic!
    var blueCharacteric: CBCharacteristic!
    
    let BEAN_SERVICE_UUID  = CBUUID(string: "a495ff20-c5b1-4b44-b512-1370f02d74de")
    let BEAN_SCRATCH_UUIDR = CBUUID(string: "a495ff21-c5b1-4b44-b512-1370f02d74de")
    let BEAN_SCRATCH_UUIDG = CBUUID(string: "a495ff22-c5b1-4b44-b512-1370f02d74de")
    let BEAN_SCRATCH_UUIDB = CBUUID(string: "a495ff23-c5b1-4b44-b512-1370f02d74de")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "Sure-Fi Devices"
        
        let backItem = UIBarButtonItem()
        backItem.title = "Back"
        navigationItem.backBarButtonItem = backItem

        let backgroundImage = UIImage(named: "background");
        let backgroundImageView = UIImageView(image: backgroundImage);
        backgroundImageView.contentMode = UIViewContentMode.scaleAspectFill;
        self.tableView.backgroundView = backgroundImageView;
        
        centralManager = CBCentralManager(delegate: self, queue: nil)
        
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Test", style: .plain, target: self, action: #selector(testBluetooth))
   }
    
    func centralManagerDidUpdateState(_ central: CBCentralManager)
    {
        
        if (central.state == CBManagerState.poweredOn)
        {
            self.centralManager!.scanForPeripherals(withServices: nil, options: nil)
        }
        else
        {
            let alert: UIAlertController = UIAlertController(title: "Bluetooth Error", message: "Bluetooth is not turned on.", preferredStyle: UIAlertControllerStyle.alert);
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil));
            self.present(alert,animated: true, completion: nil);
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber)
    {
        let name = peripheral.name;
        if(name?.uppercased().range(of: "BEAN") != nil || name?.uppercased().range(of: "SUREFI") != nil) {
            if(!surefiDevices.contains(peripheral)) {
                surefiDevices.append(peripheral);
            }
        }
        else {
            if(!peripherals.contains(peripheral)) {
                peripherals.append(peripheral)
            }
        }
        tableView.reloadData()
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        peripheral.discoverServices(nil);
        connectedPeripheral = peripheral
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        for service in peripheral.services! {
            let thisService = service as CBService
            
            if service.uuid == BEAN_SERVICE_UUID {
                peripheral.discoverCharacteristics(nil,for: thisService)
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral,didDiscoverCharacteristicsFor service: CBService,error: Error?) {
        for characteristic in service.characteristics! {
            let thisCharacteristic = characteristic as CBCharacteristic
            
            if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDR {
                peripheral.setNotifyValue(true,for: thisCharacteristic)
                print("Red Characteristic")
                print(thisCharacteristic)
                redCharacteric = thisCharacteristic
            }
            if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDG {
                peripheral.setNotifyValue(true,for: thisCharacteristic)
                print("Green Characteristic")
                print(thisCharacteristic)
                greenCharacteric = thisCharacteristic
            }
            if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDB {
                peripheral.setNotifyValue(true,for: thisCharacteristic)
                print("Blue Characteristic")
               print(thisCharacteristic)
                blueCharacteric = thisCharacteristic
           }
        }
    }
    
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        
        if characteristic==redCharacteric {
            print("Red Characteristic")
        }
        if characteristic==greenCharacteric {
            print("Green Characteristic")
        }
        if characteristic==blueCharacteric {
            print("Blue Characteristic")
        }
        let value = characteristic.value! as Data
        let stringValue = NSString(data: value, encoding: String.Encoding.utf8.rawValue) as? String
        print(stringValue ?? "")
    }
    
    func testBluetooth(sender :UIBarButtonItem) {
        print("Test")
        if connectedPeripheral.state == CBPeripheralState.connected {
            print("Is Connected")
            
            var parameter = NSInteger(255)
            let data1 = NSData(bytes: &parameter, length: 1)
            parameter = NSInteger(0)
            let data2 = NSData(bytes: &parameter, length: 1)
            parameter = NSInteger(255)
            let data3 = NSData(bytes: &parameter, length: 1)
            connectedPeripheral.writeValue(data1 as Data, for: redCharacteric, type: CBCharacteristicWriteType.withResponse)
            connectedPeripheral.writeValue(data2 as Data, for: greenCharacteric, type: CBCharacteristicWriteType.withResponse)
            connectedPeripheral.writeValue(data3 as Data, for: blueCharacteric, type: CBCharacteristicWriteType.withResponse)
            //connectedPeripheral.writeValue(data: data, forCharacteristic: redCharacteric, type: CBCharacteristicWriteType.WithResponse)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        for peripheral in surefiDevices {
            centralManager.cancelPeripheralConnection(peripheral)
        }
        for peripheral in peripherals {
            centralManager.cancelPeripheralConnection(peripheral)
        }
        centralManager?.stopScan()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let header: UITableViewHeaderFooterView = view as! UITableViewHeaderFooterView;
        header.textLabel?.textColor = UIColor.white;
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section==0 {
            return "Available Sure-Fi Devices"
        }
        if section==1 {
            return "Other Bluetooth Devices"
        }
        return ""
    }
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section==0 {
            //SureFi Devices
            return surefiDevices.count
        }
        if section==1 {
            return peripherals.count
        }
        return 0
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:UITableViewCell = self.tableView.dequeueReusableCell(withIdentifier: "cell")! as UITableViewCell
        if(indexPath.section==0) {
            let peripheral = surefiDevices[indexPath.row]
            cell.textLabel?.text = peripheral.name
            cell.detailTextLabel?.text = peripheral.identifier.uuidString;
            print(peripheral.identifier.uuidString)
            cell.accessoryType = UITableViewCellAccessoryType.disclosureIndicator;
        }
        else if(indexPath.section==1) {
            let peripheral = peripherals[indexPath.row]
            cell.textLabel?.text = peripheral.name
            cell.detailTextLabel?.text = peripheral.identifier.uuidString;
        }
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if(indexPath.section==0)
        {
            var peripheral = surefiDevices[indexPath.row]
            peripheral.delegate = self
            self.centralManager.connect(peripheral, options: nil)
            
            //let storyboard = UIStoryboard(name: "Main", bundle: nil)
            //let bluetoothDeviceViewController = storyboard.instantiateViewController(withIdentifier: "BluetoothDeviceViewController") as! BluetoothDeviceViewController
            //bluetoothDeviceViewController.bluetoothDeviceDelegate = self
            //bluetoothDeviceViewController.peripheral = peripheral
            //self.navigationController?.pushViewController(bluetoothDeviceViewController, animated: true)
            
            
        }
    }
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    /*override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     
     let indexPath = self.tableView.indexPathForSelectedRow
     let peripheral = peripherals[(indexPath?.row)!]
     centralManager!.connect(peripheral, options: nil)
     
     
     bluetoothDeviceViewController = segue.destination as! BluetoothDeviceViewController
     bluetoothDeviceViewController.peripheral = peripheral
     bluetoothDeviceViewController.bluetoothDeviceDelegate = self
     }*/
    
    
}
