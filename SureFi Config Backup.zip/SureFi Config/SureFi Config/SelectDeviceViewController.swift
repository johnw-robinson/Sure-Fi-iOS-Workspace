//
//  SelectDeviceViewController.swift
//  SureFi Config
//
//  Created by John Robinson on 11/15/16.
//  Copyright © 2016 Sure-Fi. All rights reserved.
//

import UIKit
import CoreBluetooth
import AVFoundation

class SelectDeviceViewController: UIViewController,AVCaptureMetadataOutputObjectsDelegate, CBCentralManagerDelegate, CBPeripheralDelegate {
    
    @IBOutlet var cameraView: UIView!
    @IBOutlet var deviceListView: UIView!
    @IBOutlet var messageLabel: UILabel!
    @IBOutlet var confirmButton: UIButton!
    @IBOutlet var clearButton: UIButton!
    @IBOutlet var instructionsLabel: UILabel!
    
    var centralManager: CBCentralManager!
    var surefiDevices: Array<CBPeripheral> = Array<CBPeripheral>()
    var peripheral: CBPeripheral!
    var systemDeviceField: String!
    
    var captureSession = AVCaptureSession();
    var sessionOutput = AVCapturePhotoOutput();
    var sessionOutputSetting = AVCapturePhotoSettings(format: [AVVideoCodecKey:AVVideoCodecJPEG]);
    var previewLayer = AVCaptureVideoPreviewLayer();
    
    var selectDeviceTableViewController: SelectDeviceTableViewController!
    var newSystemTableViewController: NewSystemTableViewController!
    var lynkConfigTableViewController: LynkConfigTableViewController!
    var lynkTroubleshootingTableViewController: LynkTroubleshootingTableViewController!

    
    var selectedDeviceID: String!
    var scannedDeviceID: String!
    var deviceFound: Bool = false
    
    let BEAN_SCRATCH_UUID = CBUUID(string: "a495ff21-c5b1-4b44-b512-1370f02d74de")
    let BEAN_SERVICE_UUID = CBUUID(string: "a495ff20-c5b1-4b44-b512-1370f02d74de")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "Select Device"
        
        centralManager = CBCentralManager(delegate: self, queue: nil)
        
        deviceListView.layer.borderColor = UIColor.gray.cgColor
        deviceListView.layer.borderWidth = 2
        deviceListView.layer.cornerRadius = 15
        deviceListView.clipsToBounds = true
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        selectDeviceTableViewController = storyboard.instantiateViewController(withIdentifier: "SelectDeviceTableViewController") as! SelectDeviceTableViewController
        selectDeviceTableViewController.surefiDevices = surefiDevices
        selectDeviceTableViewController.selectDeviceViewController = self
        
        selectDeviceTableViewController.view.frame = CGRect(x: 0, y: 0, width: deviceListView.frame.size.width, height: deviceListView.frame.size.height)
        deviceListView.addSubview(selectDeviceTableViewController.view)
        
        selectedDeviceID = ""
        scannedDeviceID = ""
        
        if(systemDeviceField != nil && systemDeviceField == "lynk_central_id") {
            instructionsLabel.text = "Please scan the QR Code for your Sure-Fi Lynk Central Unit"
        }
        else if(systemDeviceField != nil && systemDeviceField == "lynk_remote_id") {
            instructionsLabel.text = "Please scan the QR Code for your Sure-Fi Lynk Remote Unit"
        }
        // Do any additional setup after loading the view.
    }
    
    func centralManagerDidUpdateState(_ central: CBCentralManager)
    {
        
        if (central.state == CBManagerState.poweredOn)
        {
            self.centralManager!.scanForPeripherals(withServices: nil, options: nil)
        }
        else
        {
            let alert: UIAlertController = UIAlertController(title: "Bluetooth Error", message: "Bluetooth is not turned on.", preferredStyle: UIAlertControllerStyle.alert);
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil));
            self.present(alert,animated: true, completion: nil);
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber)
    {
        let name = peripheral.name;
        if(name?.uppercased().range(of: "BEAN") != nil || name?.uppercased().range(of: "SUREFI") != nil) {
            if(!surefiDevices.contains(peripheral)) {
                surefiDevices.append(peripheral);
                selectDeviceTableViewController.surefiDevices = surefiDevices
                selectDeviceTableViewController.tableView.reloadData()
            }
        }
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        peripheral.discoverServices(nil);
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        for service in peripheral.services! {
            let thisService = service as CBService
            
            if service.uuid == BEAN_SERVICE_UUID {
                peripheral.discoverCharacteristics(nil,for: thisService)
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral,didDiscoverCharacteristicsFor service: CBService,error: Error?) {
        for characteristic in service.characteristics! {
            let thisCharacteristic = characteristic as CBCharacteristic
            
            if thisCharacteristic.uuid == BEAN_SCRATCH_UUID {
                self.peripheral.setNotifyValue(true,for: thisCharacteristic)
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        for peripheral in surefiDevices {
            centralManager.cancelPeripheralConnection(peripheral)
        }
        centralManager?.stopScan()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        let deviceDiscoverySession = AVCaptureDeviceDiscoverySession(deviceTypes: [AVCaptureDeviceType.builtInDuoCamera, AVCaptureDeviceType.builtInTelephotoCamera,AVCaptureDeviceType.builtInWideAngleCamera], mediaType: AVMediaTypeVideo, position: AVCaptureDevicePosition.unspecified)
        for device in (deviceDiscoverySession?.devices)! {
            if(device.position == AVCaptureDevicePosition.back){
                do{
                    let input = try AVCaptureDeviceInput(device: device)
                    if(captureSession.canAddInput(input)){
                        captureSession.addInput(input);
                        
                        let captureMetadataOutput = AVCaptureMetadataOutput()
                        captureSession.addOutput(captureMetadataOutput)
                        
                        captureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
                        captureMetadataOutput.metadataObjectTypes = [AVMetadataObjectTypeQRCode]
                        
                        if(captureSession.canAddOutput(sessionOutput)){
                            captureSession.addOutput(sessionOutput);
                            previewLayer = AVCaptureVideoPreviewLayer(session: captureSession);
                            previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
                            previewLayer.connection.videoOrientation = AVCaptureVideoOrientation.portrait;
                            cameraView.layer.addSublayer(previewLayer);
                            previewLayer.frame = cameraView.bounds
                            captureSession.startRunning()
                        }
                    }
                }
                catch{
                    print("exception!");
                }
            }
        }
    }
    func captureOutput(_ captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [Any]!, from connection: AVCaptureConnection!) {
        
        // Check if the metadataObjects array is not nil and it contains at least one object.
        if metadataObjects == nil || metadataObjects.count == 0 {
            messageLabel.text = "No QR code is detected"
            return
        }
        
        // Get the metadata object.
        let metadataObj = metadataObjects[0] as! AVMetadataMachineReadableCodeObject
        
        if metadataObj.type == AVMetadataObjectTypeQRCode {
            // If the found metadata is equal to the QR code metadata then update the status label's text and set the bounds
            let barCodeObject = previewLayer.transformedMetadataObject(for: metadataObj as! AVMetadataMachineReadableCodeObject) as! AVMetadataMachineReadableCodeObject
            //cameraView?.frame = barCodeObject.bounds;
            
            if metadataObj.stringValue != nil {
                scannedDeviceID = metadataObj.stringValue
                captureSession.stopRunning()
                selectDeviceTableViewController.selectedDeviceID = scannedDeviceID
                selectDeviceTableViewController.tableView.reloadData()
                clearButton.isHidden = false
                
                if(surefiDevices.count==0) {
                    self.setDeviceFound(found: false, deviceID: "")
                }
            }
        }
    }
    
    @IBAction func toggleBluetoothDevices (sender: UIButton) {
        deviceListView.isHidden = !deviceListView.isHidden
    }
    
    @IBAction func confirmButtonPress (sender: UIButton) {
        if newSystemTableViewController != nil {
            newSystemTableViewController.setSystemDataValue(field: systemDeviceField, value: selectedDeviceID)
            newSystemTableViewController.tableView.reloadData()
        }
        else if lynkConfigTableViewController != nil {
            lynkConfigTableViewController.setSystemDataValue(field: systemDeviceField, value: selectedDeviceID)
            lynkConfigTableViewController.tableView.reloadData()
        }
        else if lynkTroubleshootingTableViewController != nil {
            lynkTroubleshootingTableViewController.setSystemDataValue(field: systemDeviceField, value: selectedDeviceID)
            lynkTroubleshootingTableViewController.tableView.reloadData()
        }
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func clearButtonPress (sender: UIButton) {
        messageLabel.text = ""
        cameraView.layer.borderColor = UIColor.gray.cgColor
        captureSession.startRunning()
        selectDeviceTableViewController.selectedDeviceID = ""
        selectDeviceTableViewController.tableView.reloadData()
        scannedDeviceID = ""
        clearButton.isHidden = true
        self.setDeviceFound(found: false, deviceID: "")
    }
    
    func setDeviceFound (found: Bool, deviceID: String) {
        deviceFound = found
        selectedDeviceID = deviceID
        if deviceFound {
            confirmButton.isHidden = false
            self.messageLabel.text = "Device Found"
            self.messageLabel.textColor = UIColor.green

        }
        else {
            confirmButton.isHidden = true
            if(scannedDeviceID != "") {
                self.messageLabel.text = "Device Not Found with Bluetooth"
                self.messageLabel.textColor = UIColor.red
                //let alert = UIAlertController(title: "Device Not Found", message: "Unable to connect to the expected device with Bluetooth. Please ensure the Sure-Fi Device is in Pairing/Conguration mode", preferredStyle: UIAlertControllerStyle.alert)
                //let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                //alert.addAction(ok)
                //self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    func getDeviceFound () -> Bool {
        return deviceFound
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
