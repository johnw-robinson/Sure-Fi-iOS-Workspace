//
//  LynkTroubleshootingTableViewController.swift
//  SureFi Config
//
//  Created by John Robinson on 11/30/16.
//  Copyright © 2016 Sure-Fi. All rights reserved.
//

import UIKit
import CoreBluetooth

class LynkTroubleshootingTableViewController: UITableViewController, CBCentralManagerDelegate, CBPeripheralDelegate {

    var lynkSystemData :[String:String] = [:]

    var centralManager: CBCentralManager!
    var peripherals: Array<CBPeripheral> = Array<CBPeripheral>()
    var centralPeripheral: CBPeripheral!
    var remotePeripheral: CBPeripheral!
    var surefiDevices: Array<CBPeripheral> = Array<CBPeripheral>()

    let BEAN_SERVICE_UUID       = CBUUID(string: "a495ff20-c5b1-4b44-b512-1370f02d74de")
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let backgroundImage = UIImage(named: "background");
        let backgroundImageView = UIImageView(image: backgroundImage);
        backgroundImageView.contentMode = UIViewContentMode.scaleAspectFill;
        self.tableView.backgroundView = backgroundImageView;
        
        let backItem = UIBarButtonItem()
        backItem.title = "Back"
        navigationItem.backBarButtonItem = backItem
        
        navigationItem.title = "Troubleshoot Sure-Fi Lynk"
        
        centralManager = CBCentralManager(delegate: self, queue: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        if (lynkSystemData["lynk_remote_id"]==nil || lynkSystemData["lynk_remote_id"]=="") {
            return 1
        }
        return 2
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            if (lynkSystemData["lynk_central_id"] != nil && lynkSystemData["lynk_central_id"] != "") {
                return 6
            }
        }
        return 1
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 80
        }
        return 64
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        if section == 0 {
            return "Lynk Central Unit"
        }
        else if section == 1 {
            return "Lynk Remote Unit"
        }
        return ""
    }
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let header: UITableViewHeaderFooterView = view as! UITableViewHeaderFooterView;
        header.textLabel?.textColor = UIColor.white;
    }
    
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell : UITableViewCell!
        
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                cell = tableView.dequeueReusableCell(withIdentifier: "DeviceSelectCell", for: indexPath)
                
                let deviceImageView: UIImageView = cell.viewWithTag(100) as! UIImageView
                let deviceTitleLabel: UILabel = cell.viewWithTag(200) as! UILabel
                let deviceDescLabel: UILabel = cell.viewWithTag(300) as! UILabel
                
                if (lynkSystemData["lynk_central_id"]==nil || lynkSystemData["lynk_central_id"]=="")
                {
                    deviceImageView.image = UIImage(named: "select_icon")
                    deviceTitleLabel.text = "Select Cental Unit"
                    deviceDescLabel.text = "Compatable Sure-Fi Lynk Device"
                }
                else
                {
                    deviceImageView.image = UIImage(named: "lynk_hardware_icon")
                    deviceTitleLabel.text = "Central Unit"
                    deviceDescLabel.text = lynkSystemData["lynk_central_id"]
                    
                    for device in surefiDevices {
                        if(device.identifier.uuidString == lynkSystemData["lynk_central_id"]) {
                            centralPeripheral = device
                            centralPeripheral.delegate = self
                            centralManager.connect(device, options: nil)
                        }
                    }
                }
            }
            if indexPath.row >= 1 {
                cell = tableView.dequeueReusableCell(withIdentifier: "IssueCell", for: indexPath)
                
                let issueImageView: UIImageView = cell.viewWithTag(100) as! UIImageView
                let issueTitleLabel: UILabel = cell.viewWithTag(200) as! UILabel
                let issueDescLabel: UILabel = cell.viewWithTag(300) as! UILabel
                
                if indexPath.row == 1 {
                    issueImageView.image = UIImage(named: "error_icon")
                    issueTitleLabel.text = "Remote Unit missing peripheral device"
                    issueDescLabel.text = "The remote Sure-Fi Lynk unit does not have a peripheral device connected and will not function properly as configured"
                }
                if indexPath.row == 2 {
                    issueImageView.image = UIImage(named: "error_icon")
                    issueTitleLabel.text = "Sure-Fi Lynk peripheral mismatch"
                    issueDescLabel.text = "The peripheral devices configured for the Central and Remote Units are not compatible"
                }
                if indexPath.row == 3 {
                    issueImageView.image = UIImage(named: "warning_icon")
                    issueTitleLabel.text = "Lynk Signal Strength"
                    issueDescLabel.text = "The signal strength between the Central and Remote units is low. Please adjust settings to increase signal strength"
                }
                if indexPath.row == 4 {
                    issueImageView.image = UIImage(named: "warning_icon")
                    issueTitleLabel.text = "Solar Flare Detected"
                    issueDescLabel.text = "The Sure-Fi Lynk has detected a solar flare which may disrupt the signal between the Central and Remote units"
                }
                if indexPath.row == 5 {
                    issueImageView.image = UIImage(named: "warning_icon")
                    issueTitleLabel.text = "Firmware Update Available"
                    issueDescLabel.text = "The Remote Unit has a firmware update available."
                }
                
                
                
                
            }
        }
        return cell
    }
    
    func setSystemDataValue( field: String, value: String) {
        lynkSystemData[field] = value
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let indexPath = self.tableView.indexPathForSelectedRow!
        
        if(segue.identifier=="SelectDeviceSegue") {
            let destinationVC = segue.destination as! SelectDeviceViewController
            destinationVC.lynkTroubleshootingTableViewController = self
            if indexPath.section==0 {
                destinationVC.systemDeviceField = "lynk_central_id"
            }
            if indexPath.section==1 {
                destinationVC.systemDeviceField = "lynk_remote_id"
            }
        }
        if segue.identifier == "IssueDetailsSegue" {
            
            let selectedCell = tableView(self.tableView, cellForRowAt: self.tableView.indexPathForSelectedRow!) as! UITableViewCell

            let issueImageView: UIImageView = selectedCell.viewWithTag(100) as! UIImageView
            let issueTitleLabel: UILabel = selectedCell.viewWithTag(200) as! UILabel
            let issueDescLabel: UILabel = selectedCell.viewWithTag(300) as! UILabel
            
            let destinationVC = segue.destination as! LynkIssueDetailTableViewController
            destinationVC.issueTitle = issueTitleLabel.text
            destinationVC.issueDetails = issueDescLabel.text
            destinationVC.issueTypeImage = issueImageView.image
            
        }
        
    }
    


    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func centralManagerDidUpdateState(_ central: CBCentralManager)
    {
        if (central.state == CBManagerState.poweredOn)
        {
            self.centralManager!.scanForPeripherals(withServices: nil, options: nil)
        }
        else
        {
            let alert: UIAlertController = UIAlertController(title: "Bluetooth Error", message: "Bluetooth is not turned on.", preferredStyle: UIAlertControllerStyle.alert);
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil));
            self.present(alert,animated: true, completion: nil);
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber)
    {
        let name = peripheral.name;
        if(name?.uppercased().range(of: "BEAN") != nil || name?.uppercased().range(of: "SUREFI") != nil) {
            if(!surefiDevices.contains(peripheral)) {
                surefiDevices.append(peripheral);
            }
        }
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        if centralPeripheral != nil && peripheral == centralPeripheral {
            centralPeripheral.discoverServices(nil)
        }
        if remotePeripheral != nil && peripheral == remotePeripheral {
            remotePeripheral.discoverServices(nil)
        }
        
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        for service in peripheral.services! {
            let thisService = service as CBService
            
            if service.uuid == BEAN_SERVICE_UUID {
                peripheral.discoverCharacteristics(nil,for: thisService)
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral,didDiscoverCharacteristicsFor service: CBService,error: Error?) {
        for characteristic in service.characteristics! {
            let thisCharacteristic = characteristic as CBCharacteristic
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        
        let value = characteristic.value! as Data
        let stringValue = NSString(data: value, encoding: String.Encoding.utf8.rawValue) as? String ?? ""
    }


}
