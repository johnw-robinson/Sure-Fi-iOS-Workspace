//
//  LoginViewController.swift
//  SureFi Config
//
//  Created by John Robinson on 10/21/16.
//  Copyright © 2016 Sure-Fi. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet var userName: UITextField!
    @IBOutlet var userPass: UITextField!
    @IBOutlet var loginButton :UIButton!
    @IBOutlet var landingView: UIView!
    @IBOutlet var loginView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        loginView.isHidden = true
        landingView.isHidden = false
        
        UIApplication.shared.statusBarStyle = .lightContent
        
        
        let paddingView1 = UIView(frame: CGRect(x: 0, y: 0, width: 45, height: 45))
        let paddingView2 = UIView(frame: CGRect(x: 0, y: 0, width: 45, height: 45))
        
        let accountImage = UIImageView(frame: CGRect(x: 0, y: 0, width: 45, height: 45))
        accountImage.image = UIImage(named: "account_image")
        
        let passwordImage = UIImageView(frame: CGRect(x: 0, y: 0, width: 45, height: 45))
        passwordImage.image = UIImage(named: "password_image")
        
        userName.leftView = paddingView1;
        userName.leftViewMode = .always
        userName.addSubview(accountImage)
        
        userPass.leftView = paddingView2
        userPass.leftViewMode = .always
        userPass.addSubview(passwordImage)
        
        // Do any additional setup after loading the view.
    }

    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func showLoginView(sender: UIButton) {
        loginView.isHidden = false
        UIView.transition(from: landingView, to: loginView, duration: 0.5, options: .transitionFlipFromLeft, completion: nil)
    }
    
    @IBAction func showLandingView(sender: UIButton) {
        loginView.isHidden = true
        UIView.transition(from: loginView, to: landingView, duration: 0.5, options: .transitionFlipFromRight, completion: nil)
    }
    
    @IBAction func lynkButtonPress(sender: UIButton) {
        self.navigationController?.isNavigationBarHidden = false
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "LynkSetupTableViewController") as! LynkSetupTableViewController
        self.navigationController?.pushViewController(controller, animated: false)
    }
    
    @IBAction func loginButtonPress(sender: UIButton) {
        
        var userLoginString :String = userName.text!.toBase64()
        var userPassString :String = userPass.text!.toBase64()
        
        userLoginString = userLoginString.replacingOccurrences(of: "=", with: "")
        userPassString = userPassString.replacingOccurrences(of: "=", with: "")
        
        let results : NSMutableDictionary = Util().getServerRequest(action: "check_user_login", apiData: "\(userLoginString)/\(userPassString)")
       
        if results["status"] as! String == "success" {
            let userData:NSDictionary = results["data"] as! NSDictionary
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            UserDefaults.standard.setValue(userData["user_login"], forKey: "user_login");
            UserDefaults.standard.setValue(userData["user_password"], forKey: "user_password");
            
            self.navigationController?.isNavigationBarHidden = false
            appDelegate.isLoggedIn = true
            appDelegate.userData = userData as? NSMutableDictionary;
            appDelegate.sessionKey = userData.object(forKey: "session_key") as! String?
            appDelegate.userKey = userData.object(forKey: "user_key") as! String?

            self.navigationController?.popViewController(animated: true)
        }
        else {
            let alertController = UIAlertController(title: "Login Error", message: results["message"] as? String, preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(okAction)
            self.present(alertController, animated: true, completion: nil)
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
