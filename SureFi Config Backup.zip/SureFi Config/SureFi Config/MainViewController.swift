//
//  MainViewController.swift
//  SureFi Config
//
//  Created by John Robinson on 10/19/16.
//  Copyright © 2016 Sure-Fi. All rights reserved.
//

import UIKit

class MainViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {

    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    
    
    @IBOutlet var menuCollectionView: UICollectionView!

    override func viewDidLoad() {
        super.viewDidLoad()

        if !appDelegate.isLoggedIn! {
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let controller = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
            self.navigationController?.pushViewController(controller, animated: false)
        }
        
        let logoImageView = UIImageView(image: UIImage(named: "sure-fi_menu"))
        self.navigationItem.titleView = logoImageView
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewDidAppear(_ animated: Bool) {
        menuCollectionView.reloadData()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if !appDelegate.isLoggedIn! {
            return 0
        }
        return 8
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MenuItem", for: indexPath as IndexPath)
        cell.layer.borderColor = UIColor.lightGray.cgColor
        cell.layer.borderWidth = 1
        cell.backgroundColor = .white
        cell.layer.cornerRadius = 10
        cell.clipsToBounds = true
        
        let menuItemImage: UIImageView = cell.viewWithTag(100) as! UIImageView
        let menuItemLabel: UILabel = cell.viewWithTag(200) as! UILabel
        menuItemLabel.textColor = UIColor(red: 3/255, green: 46/255, blue: 82/255, alpha: 1)
        menuItemLabel.layer.shadowColor = UIColor.white.cgColor
        menuItemLabel.layer.shadowOffset = CGSize(width: 0, height: 0)
        menuItemLabel.layer.shadowOpacity = 2
        menuItemLabel.layer.shadowRadius = 3
        
        switch indexPath.row {
        case 0:
            menuItemImage.image = UIImage(named: "account_icon")
            menuItemLabel.text = "My Account"
        case 1:
            menuItemImage.image = UIImage(named: "customers_icon")
            menuItemLabel.text = "Customers"
        case 2:
            menuItemImage.image = UIImage(named: "licensing_icon")
            menuItemLabel.text = "Licensing"
        case 3:
            menuItemImage.image = UIImage(named: "device_configure_icon")
            menuItemLabel.text = "Configure Device"
        case 4:
            menuItemImage.image = UIImage(named: "cloud_icon")
            menuItemLabel.text = "Sure-Fi Cloud"
        case 5:
            menuItemImage.image = UIImage(named: "systems_icon")
            menuItemLabel.text = "Sure-Fi Systems"
        case 6:
            menuItemImage.image = UIImage(named: "settings_icon")
            menuItemLabel.text = "Settings"
        case 7:
            menuItemImage.image = UIImage(named: "logout_icon")
            menuItemLabel.text = "Log Out"
        default:
            menuItemImage.image = UIImage(named: "")
        }
        return cell    // Create UICollectionViewCell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath as IndexPath, animated: false)

        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        switch indexPath.row {
        case 0:
            let results : NSMutableDictionary = Util().getServerRequest(action: "get_user_account", apiData: "\(appDelegate.sessionKey!)/\(appDelegate.userData!.object(forKey: "user_key")!)")
            if results["status"] as! String == "success"
            {
                let accountTableController :AccountTableViewController = storyboard.instantiateViewController(withIdentifier: "AccountTableViewController") as! AccountTableViewController
                accountTableController.accountInfo = results.object(forKey: "data") as! NSMutableDictionary
                self.navigationController?.pushViewController(accountTableController, animated: true)
            }
            else
            {
                let alertController = UIAlertController(title: "API Error", message: results["message"] as? String, preferredStyle: .alert)
                let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertController.addAction(okAction)
                self.present(alertController, animated: true, completion: nil)
            }
            
        case 3:
            let bluetoothDeviceTableController :BluetoothDevicesTableViewController = storyboard.instantiateViewController(withIdentifier: "BluetoothDevicesTableViewController") as! BluetoothDevicesTableViewController
            self.navigationController?.pushViewController(bluetoothDeviceTableController, animated: true)
        case 5:
            let systemsTableViewController :SystemsTableViewController = storyboard.instantiateViewController(withIdentifier: "SystemsTableViewController") as! SystemsTableViewController
            self.navigationController?.pushViewController(systemsTableViewController, animated: true)
        case 7:
            let logoutAlert: UIAlertController = UIAlertController(title: "Log Out?", message: "Are you sure you want to Log Out?", preferredStyle: .alert)
            let okAction: UIAlertAction = UIAlertAction(title: "OK", style: .default, handler: { action in
                self.appDelegate.isLoggedIn = false
                
                self.appDelegate.userData = nil
                self.appDelegate.sessionKey = nil
                
                for key in UserDefaults.standard.dictionaryRepresentation().keys {
                    UserDefaults.standard.removeObject(forKey: key.description)
                }
                
                self.viewDidLoad()
            })
            let cancelAction: UIAlertAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            logoutAlert.addAction(okAction)
            logoutAlert.addAction(cancelAction)
            self.present(logoutAlert, animated: true, completion: nil)
        default:
            print(indexPath.row)
        }
    }
    
    // MARK: UICollectionViewDelegateFlowLayout
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let fullWidth = self.view.frame.width-20
        var paddedWidth = fullWidth-20
        var colCount:CGFloat = 1
        
        while paddedWidth>256 {
            colCount+=1
            let colPadding:CGFloat = 20*colCount
            paddedWidth = (fullWidth - colPadding)/colCount
        }
        return CGSize(width: paddedWidth, height: paddedWidth) // The size of one cell
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
