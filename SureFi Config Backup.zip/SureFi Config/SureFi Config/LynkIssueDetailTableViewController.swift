//
//  LynkIssueDetailTableViewController.swift
//  SureFi Config
//
//  Created by John Robinson on 11/30/16.
//  Copyright © 2016 Sure-Fi. All rights reserved.
//

import UIKit

class LynkIssueDetailTableViewController: UITableViewController {

    var issueTitle: String!
    var issueDetails: String!
    var issueTypeImage: UIImage!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let backgroundImage = UIImage(named: "background");
        let backgroundImageView = UIImageView(image: backgroundImage);
        backgroundImageView.contentMode = UIViewContentMode.scaleAspectFill;
        self.tableView.backgroundView = backgroundImageView;
        
        let backItem = UIBarButtonItem()
        backItem.title = "Back"
        navigationItem.backBarButtonItem = backItem
        
        navigationItem.title = "Issue Details"
     }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 2
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        if section == 0 {
            return "Issue Details"
        }
        else if section == 1 {
            return "Possible Solutions"
        }
        return ""
    }
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let header: UITableViewHeaderFooterView = view as! UITableViewHeaderFooterView;
        header.textLabel?.textColor = UIColor.white;
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.section == 0 && indexPath.row == 0) {
            return 64
        }
        if(indexPath.section == 0 && indexPath.row == 1) {
            return 256
        }
        return 80
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell : UITableViewCell!
        
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                cell = tableView.dequeueReusableCell(withIdentifier: "IssueTitleCell", for: indexPath)
                
                let issueImageView: UIImageView = cell.viewWithTag(100) as! UIImageView
                let issueTitleLabel: UILabel = cell.viewWithTag(200) as! UILabel
                issueTitleLabel.text = issueTitle
                issueImageView.image = issueTypeImage
            }
            if indexPath.row == 1 {
                cell = tableView.dequeueReusableCell(withIdentifier: "IssueDetailsCell", for: indexPath)
                
                let issueDetailsView: UITextView = cell.viewWithTag(100) as! UITextView
                issueDetailsView.text = issueDetails
            }
        }
        if indexPath.section == 1 {
            cell = tableView.dequeueReusableCell(withIdentifier: "OptionsCell", for: indexPath)
            let optionImageView: UIImageView = cell.viewWithTag(100) as! UIImageView
            let optionTitleLabel: UILabel = cell.viewWithTag(200) as! UILabel
            let optionDescLabel: UILabel = cell.viewWithTag(300) as! UILabel
            
            if indexPath.row == 0 {
                optionImageView.image = UIImage(named: "move_icon")
                optionTitleLabel.text = "Adjust position of Sure-Fi Lynk Unit"
                optionDescLabel.text = "Moving the Sure-Fi Lynk to a different position and/or orientation may solve this issue"
            }
            if indexPath.row == 1 {
                optionImageView.image = UIImage(named: "restart_icon")
                optionTitleLabel.text = "Power Cycle Sure-Fi Lynk Unit"
                optionDescLabel.text = "Restarting the Sure-Fi Lynk Unit may help solve this issue"
            }
            
        }

        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
