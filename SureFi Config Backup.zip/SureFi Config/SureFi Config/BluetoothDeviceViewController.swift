//
//  BluetoothDeviceViewController.swift
//  SureFi Config
//
//  Created by John Robinson on 10/20/16.
//  Copyright © 2016 Sure-Fi. All rights reserved.
//

import UIKit
import CoreBluetooth

class BluetoothDeviceViewController: UIViewController,CBPeripheralDelegate {

    var peripheral: CBPeripheral?
    var bluetoothDeviceDelegate : BluetoothDevicesTableViewController?
    
    let BEAN_SERVICE_UUID = CBUUID(string: "a495ff20-c5b1-4b44-b512-1370f02d74de")
    let BEAN_SCRATCH_UUIDR = CBUUID(string: "a495ff21-c5b1-4b44-b512-1370f02d74de")
    let BEAN_SCRATCH_UUIDG = CBUUID(string: "a495ff22-c5b1-4b44-b512-1370f02d74de")
    let BEAN_SCRATCH_UUIDB = CBUUID(string: "a495ff23-c5b1-4b44-b512-1370f02d74de")

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        //peripheral?.delegate = self
        //bluetoothDeviceDelegate?.centralManager.connect(peripheral!, options: nil)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        for service in peripheral.services! {
            let thisService = service as CBService
            
            if service.uuid == BEAN_SERVICE_UUID {
                peripheral.discoverCharacteristics(nil,for: thisService)
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral,didDiscoverCharacteristicsFor service: CBService,error: Error?) {
        for characteristic in service.characteristics! {
            let thisCharacteristic = characteristic as CBCharacteristic
            
            if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDR {
                peripheral.setNotifyValue(true,for: thisCharacteristic)
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.bluetoothDeviceDelegate?.centralManager.cancelPeripheralConnection(peripheral!)
    }
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
