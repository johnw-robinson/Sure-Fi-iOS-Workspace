//
//  NewSystemTableViewController.swift
//  SureFi Config
//
//  Created by John Robinson on 11/15/16.
//  Copyright © 2016 Sure-Fi. All rights reserved.
//

import UIKit

class NewSystemTableViewController: UITableViewController,SelectTableViewControllerDelegate {
    
    var newSystemData :[String:String] = [:]
    var customersList :NSMutableArray!
    var allowTypeSelect :Bool!
    var lynkPeripheals :NSMutableDictionary!
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backgroundImage = UIImage(named: "background");
        let backgroundImageView = UIImageView(image: backgroundImage);
        backgroundImageView.contentMode = UIViewContentMode.scaleAspectFill;
        self.tableView.backgroundView = backgroundImageView;
        
        let backItem = UIBarButtonItem()
        backItem.title = "Back"
        navigationItem.backBarButtonItem = backItem
        
        navigationItem.title = "New Sure-Fi System"
        
        if allowTypeSelect == nil {
            allowTypeSelect = true
        }
        
        if appDelegate.userData == nil {
            appDelegate.userKey = "12345678-1234-XXXX-XXXX-0123456789AB";
            
            let timestamp = Int(NSDate().timeIntervalSince1970)
            let timestampstring = String(format:"%2X", timestamp)
            let sessionKey = String("12345678\(timestampstring)".characters.reversed())
            
            appDelegate.sessionKey = sessionKey
        }
        
        let results : NSMutableDictionary = Util().getServerRequest(action: "get_lynk_peripherals", apiData: "")
        if results["status"] != nil && results["status"] as! String == "success" {
            
            lynkPeripheals = results["data"] as! NSMutableDictionary
        }
        else if results["status"] as! String == "failure" {
            let apiMessage = results["message"] as! String
            let alert = UIAlertController(title: "Configuration Error", message: apiMessage, preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(ok)
            self.present(alert, animated: true, completion: nil)
            self.navigationItem.setHidesBackButton(false, animated: false)
        }
        
        
        //let results : NSMutableDictionary = Util().getServerRequest(action: "get_customers", apiData: "")
        //customersList = results["data"] as! NSMutableArray
        
        //print(customersList)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let header: UITableViewHeaderFooterView = view as! UITableViewHeaderFooterView;
        header.textLabel?.textColor = UIColor.white;
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.section==0 && indexPath.row==0) {
            return 80
        }
        if((indexPath.section==1 || indexPath.section==2 || indexPath.section==4) && newSystemData["type"]=="lynk") {
            return 80
        }
        return 44
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if(section==0) {
            return "Type of System"
        }
        if(section==1) {
            if newSystemData["type"]=="lynk" {
                return "Central Unit"
            }
        }
        if(section==2) {
            if newSystemData["type"]=="lynk" {
                return "Remote Unit"
            }
        }
        if(section==2) {
            return "System Details"
        }
        return ""
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        if(newSystemData["type"]==nil || newSystemData["type"]=="") {
            return 1
        }
        if(newSystemData["type"]=="lynk") {
            if(newSystemData["lynk_central_id"] != nil && newSystemData["lynk_central_id"] != "" && newSystemData["lynk_remote_id"] != nil && newSystemData["lynk_remote_id"] != "") {
                return 5
            }
            return 3
        }
        return 0
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(section==0) {
            return 1
        }
        else if(newSystemData["type"]=="lynk") {
            if(section==1) {
                if(newSystemData["lynk_central_id"] != nil && newSystemData["lynk_central_id"] != "") {
                    return 2
                }
                return 1
            }
            if(section==2) {
                if(newSystemData["lynk_remote_id"] != nil && newSystemData["lynk_remote_id"] != "") {
                    return 2
                }
                return 1
            }
            if(section==3) {
                return 3
            }
            if(section==4) {
                return 1
            }
        }
        return 0
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell :UITableViewCell? = nil
        
        if(indexPath.section==0 && indexPath.row==0) {
            cell = tableView.dequeueReusableCell(withIdentifier: "SystemTypeCell", for: indexPath)
            let systemImageView: UIImageView = cell!.viewWithTag(100) as! UIImageView
            let systemTitleLabel: UILabel = cell!.viewWithTag(200) as! UILabel
            
            if(newSystemData["type"]==nil || newSystemData["type"]=="") {
                systemImageView.image = UIImage(named: "select_icon")
                systemTitleLabel.text = "Select a system type..."
            }
            else {
                let imageName = "\(newSystemData["type"]!)_icon"
                systemImageView.image = UIImage(named: imageName)
                systemTitleLabel.text = newSystemData["type_name"]
                if newSystemData["system_title"] == nil || newSystemData["system_title"] == "" {
                    newSystemData["system_title"] = "New \(newSystemData["type_name"]!)"
                }
            }
            
            if allowTypeSelect == false {
                cell?.accessoryType = .none
                cell?.selectionStyle = .none
            }
        }
        else if(indexPath.section==1 && newSystemData["type"]=="lynk") {
            if(indexPath.row==0) {
                cell = tableView.dequeueReusableCell(withIdentifier: "DeviceSelectCell", for: indexPath)
                
                let deviceImageView: UIImageView = cell!.viewWithTag(100) as! UIImageView
                let deviceTitleLabel: UILabel = cell!.viewWithTag(200) as! UILabel
                let deviceDescLabel: UILabel = cell!.viewWithTag(300) as! UILabel
                if (newSystemData["lynk_central_id"]==nil || newSystemData["lynk_central_id"]=="")
                {
                    deviceImageView.image = UIImage(named: "select_icon")
                    deviceTitleLabel.text = "Select Cental Unit"
                    deviceDescLabel.text = "Compatable Sure-Fi Lynk Device"
                }
                else
                {
                    let results : NSMutableDictionary = Util().getServerRequest(action: "check_hardware_available", apiData: "\(newSystemData["lynk_central_id"]!)")
                    if results["status"] != nil && results["status"] as! String == "success" {
                        deviceImageView.image = UIImage(named: "lynk_hardware_icon")
                        deviceTitleLabel.text = "Central Unit"
                        deviceDescLabel.text = newSystemData["lynk_central_id"]
                    }
                    else {
                        let apiMessage = results["message"] as! String
                        let alert = UIAlertController(title: "Configuration Error", message: apiMessage, preferredStyle: .alert)
                        let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                        alert.addAction(ok)
                        self.present(alert, animated: true, completion: nil)
                        newSystemData["lynk_central_id"] = ""
                        tableView.reloadData()
                    }
                }
            }
            if(indexPath.row==1) {
                cell = tableView.dequeueReusableCell(withIdentifier: "PeripheralSelectCell", for: indexPath)
                
                let peripheralImageView: UIImageView = cell!.viewWithTag(100) as! UIImageView
                let peripheralTitleLabel: UILabel = cell!.viewWithTag(200) as! UILabel
                let peripheralDescLabel: UILabel = cell!.viewWithTag(300) as! UILabel
                if (newSystemData["lynk_central_peripheral_type"]==nil || newSystemData["lynk_central_peripheral_type"]=="")
                {
                    peripheralImageView.image = UIImage(named: "peripheral_icon")
                    peripheralTitleLabel.text = "Select Peripheral Device"
                    peripheralDescLabel.text = "Compatable Sure-Fi Lynk Peripheral Device"
                }
                else
                {
                    let lynkPeriphealType: String = newSystemData["lynk_central_peripheral_type"]!
                    peripheralImageView.image = UIImage(named: "peripheal_\(lynkPeriphealType)_icon")
                    peripheralTitleLabel.text = lynkPeripheals.object(forKey: lynkPeriphealType) as! String
                    peripheralDescLabel.text = ""
                }
            }
        }
        else if(indexPath.section==2 && newSystemData["type"]=="lynk") {
            
            if(indexPath.row==0) {
                cell = tableView.dequeueReusableCell(withIdentifier: "DeviceSelectCell", for: indexPath)
                
                let deviceImageView: UIImageView = cell!.viewWithTag(100) as! UIImageView
                let deviceTitleLabel: UILabel = cell!.viewWithTag(200) as! UILabel
                let deviceDescLabel: UILabel = cell!.viewWithTag(300) as! UILabel
                
                if (newSystemData["lynk_remote_id"]==nil || newSystemData["lynk_remote_id"]=="") {
                    deviceImageView.image = UIImage(named: "select_icon")
                    deviceTitleLabel.text = "Select Remote Unit"
                    deviceDescLabel.text = "Compatable Sure-Fi Lynk Device"
                }
                else {
                    if(newSystemData["lynk_central_id"] != nil && newSystemData["lynk_central_id"] != "" && newSystemData["lynk_central_id"] == newSystemData["lynk_remote_id"]) {
                        let alert = UIAlertController(title: "Configuration Error", message: "You must select a different Sure-Fi Lynk device for the Central and Remote Units", preferredStyle: .alert)
                        let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                        alert.addAction(ok)
                        self.present(alert, animated: true, completion: nil)
                        newSystemData["lynk_remote_id"] = ""
                        tableView.reloadData()
                    }
                    else {
                        let results : NSMutableDictionary = Util().getServerRequest(action: "check_hardware_available", apiData: "\(newSystemData["lynk_remote_id"]!)")
                        if results["status"] != nil && results["status"] as! String == "success" {
                            deviceImageView.image = UIImage(named: "lynk_hardware_icon")
                            deviceTitleLabel.text = "Remote Unit"
                            deviceDescLabel.text = newSystemData["lynk_remote_id"]
                        }
                        else {
                            let apiMessage = results["message"] as! String
                            let alert = UIAlertController(title: "Configuration Error", message: apiMessage, preferredStyle: .alert)
                            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                            alert.addAction(ok)
                            self.present(alert, animated: true, completion: nil)
                            newSystemData["lynk_remote_id"] = ""
                            tableView.reloadData()
                        }
                    }
                }
            }
            if(indexPath.row==1) {
                cell = tableView.dequeueReusableCell(withIdentifier: "PeripheralSelectCell", for: indexPath)
                
                let peripheralImageView: UIImageView = cell!.viewWithTag(100) as! UIImageView
                let peripheralTitleLabel: UILabel = cell!.viewWithTag(200) as! UILabel
                let peripheralDescLabel: UILabel = cell!.viewWithTag(300) as! UILabel
                
                if (newSystemData["lynk_remote_peripheral_type"]==nil || newSystemData["lynk_remote_peripheral_type"]=="")
                {
                    peripheralImageView.image = UIImage(named: "peripheral_icon")
                    peripheralTitleLabel.text = "Select Peripheral Device"
                    peripheralDescLabel.text = "Compatable Sure-Fi Lynk Peripheral Device"
                }
                else
                {
                    let lynkPeriphealType: String = newSystemData["lynk_remote_peripheral_type"]!
                    peripheralImageView.image = UIImage(named: "peripheal_\(lynkPeriphealType)_icon")
                    peripheralTitleLabel.text = lynkPeripheals.object(forKey: lynkPeriphealType) as! String
                    peripheralDescLabel.text = ""
                }
            }
        }
        else if(indexPath.section==3 && newSystemData["type"]=="lynk") {
            
            if(indexPath.row==0) {
                cell = tableView.dequeueReusableCell(withIdentifier: "SelectCell", for: indexPath)
                let dataCellLabel: UILabel = cell!.viewWithTag(100) as! UILabel
                let dataCellDetails: UILabel = cell!.viewWithTag(200) as! UILabel
                dataCellLabel.text = "Customer"
                dataCellDetails.text = ""
                cell?.accessoryType = UITableViewCellAccessoryType.disclosureIndicator
                if(newSystemData["customer_id"] != nil && newSystemData["customer_id"] == "XX") {
                    dataCellDetails.text = "You must be logged in to select a customer"
                    dataCellDetails.textColor = UIColor.gray
                    cell?.accessoryType = .none
                }
                else if(newSystemData["customer_name"] != nil) {
                    dataCellDetails.text = newSystemData["customer_name"]
                }
            }
            if(indexPath.row==1) {
                cell = tableView.dequeueReusableCell(withIdentifier: "DataCell", for: indexPath)
                let dataCellLabel: UILabel = cell!.viewWithTag(100) as! UILabel
                let dataCellTextField: UITextField = cell!.viewWithTag(200) as! UITextField
                dataCellTextField.text = newSystemData["system_title"] ?? ""
                dataCellTextField.addTarget(self, action: #selector(setLynkTitle), for: UIControlEvents.allEditingEvents)
                dataCellLabel.text = "System Title"
            }
            if(indexPath.row==2) {
                cell = tableView.dequeueReusableCell(withIdentifier: "DataCell", for: indexPath)
                let dataCellLabel: UILabel = cell!.viewWithTag(100) as! UILabel
                let dataCellTextField: UITextField = cell!.viewWithTag(200) as! UITextField
                dataCellTextField.text = newSystemData["zip_code"] ?? ""
                dataCellTextField.frame = CGRect(x: dataCellTextField.frame.origin.x, y: dataCellTextField.frame.origin.y, width: 80, height: dataCellTextField.frame.size.height)
                dataCellTextField.keyboardType = UIKeyboardType.numbersAndPunctuation
                dataCellTextField.addTarget(self, action: #selector(setLynkZip), for: UIControlEvents.allEditingEvents)
                dataCellLabel.text = "Zip"
            }
            
        }
        else if(indexPath.section==4 && newSystemData["type"]=="lynk") {
            cell = tableView.dequeueReusableCell(withIdentifier: "CompleteCell", for: indexPath)
            let completeButton = cell!.viewWithTag(100) as! UIButton
            completeButton.addTarget(self, action: #selector(setupLynk), for: .touchUpInside)
        }
        
        // Configure the cell...
        cell?.selectionStyle = .none
        return cell!
    }
    
    func setSystemDataValue( field: String, value: String) {
        newSystemData[field] = value
    }
    
    func setLynkTitle (sender: UITextField) {
        newSystemData["system_title"] = sender.text
        print("system_title:\(sender.text)")
    }
    
    func setLynkZip (sender: UITextField) {
        if ((sender.text?.characters.count)! > 5) {
            sender.deleteBackward()
        }
        
        newSystemData["zip_code"] = sender.text
        print("zip_code:\(sender.text)")
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if( newSystemData["type"] != nil && newSystemData["type"] == "lynk") {
            if(indexPath.section==2 && indexPath.row==0 && (newSystemData["customer_id"] == nil || newSystemData["customer_id"] != "XX")) { //Select Customer
                
                var customers : [[String:String]] = []
                for tempCustomer in customersList {
                    let customer = tempCustomer as! NSMutableDictionary
                    var listItem: [String:String] = [:]
                    listItem["text"] = customer.object(forKey: "customer_name") as! String
                    listItem["description"] = "\(customer.object(forKey: "customer_address") as! String) \(customer.object(forKey: "customer_city") as! String) \(customer.object(forKey: "customer_state") as! String) \(customer.object(forKey: "customer_zip") as! String)"
                    customers.append(listItem)
                }
                
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let selectTableViewController = storyboard.instantiateViewController(withIdentifier: "SelectTableViewController") as! SelectTableViewController
                selectTableViewController.delegate = self
                selectTableViewController.list = customers
                selectTableViewController.returnIdentifier = "customer"
                selectTableViewController.sectionTitle = "Please select an active Customer"
                self.navigationController?.pushViewController(selectTableViewController, animated: true)
                
            }
        }
    }
    
    func returnSelectedRow(selectedRow : Int, list: [[String:String]], identifier: String) {
        
        if(identifier=="customer") {
            let customer = customersList.object(at: selectedRow) as! NSMutableDictionary
            newSystemData["customer_id"] = customer.object(forKey: "customer_id") as? String
            newSystemData["customer_name"] = customer.object(forKey: "customer_name") as? String
            tableView.reloadData()
        }
        
        
    }
    
    @IBAction func setupLynk (sender: UIButton) {
        
        var alert: UIAlertController!
        if newSystemData["type"] == nil || newSystemData["type"] == "" {
            alert = UIAlertController(title: "Invalid System Type", message: "You must select a valid system type to continue", preferredStyle: .alert)
            let ok = UIAlertAction(title: "Ok", style: .default, handler: nil);
            alert.addAction(ok)
        }
        else if newSystemData["lynk_central_peripheral_type"] == nil || newSystemData["lynk_central_peripheral_type"] == "" {
            alert = UIAlertController(title: "Invalid System Type", message: "You must select a valid peripheral type for the Central Unit to continue", preferredStyle: .alert)
            let ok = UIAlertAction(title: "Ok", style: .default, handler: nil);
            alert.addAction(ok)
        }
        else if newSystemData["lynk_remote_peripheral_type"] == nil || newSystemData["lynk_remote_peripheral_type"] == "" {
            alert = UIAlertController(title: "Invalid System Type", message: "You must select a valid peripheral type for the Central Unit to continue", preferredStyle: .alert)
            let ok = UIAlertAction(title: "Ok", style: .default, handler: nil);
            alert.addAction(ok)
        }
        else if newSystemData["customer_id"] == nil || newSystemData["customer_id"] == "" {
            alert = UIAlertController(title: "Invalid Customer", message: "You must select a valid customer type to continue", preferredStyle: .alert)
            let ok = UIAlertAction(title: "Ok", style: .default, handler: nil);
            alert.addAction(ok)
        }
        else if newSystemData["system_title"] == nil || newSystemData["system_title"] == "" {
            alert = UIAlertController(title: "Invalid System Title", message: "You must provide a valid system title to continue", preferredStyle: .alert)
            let ok = UIAlertAction(title: "Ok", style: .default, handler: nil);
            alert.addAction(ok)
        }
        else if newSystemData["zip_code"] == nil || newSystemData["zip_code"] == "" {
            alert = UIAlertController(title: "Invalid Zip Code", message: "You must provide a valid zip code to continue", preferredStyle: .alert)
            let ok = UIAlertAction(title: "Ok", style: .default, handler: nil);
            alert.addAction(ok)
        }
        else {
            alert = UIAlertController(title: "Initiate System Configuration", message: "Are you sure you are ready to initiate configurion of this Sure-Fi System?", preferredStyle: .alert)
            let ok = UIAlertAction(title: "Continue", style: .default, handler: continueSetup);
            let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            alert.addAction(ok)
            alert.addAction(cancel)
        }
        self.present(alert, animated: true, completion: nil)
    }
    
    func continueSetup(alert: UIAlertAction!) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let lynkConfigViewController = storyboard.instantiateViewController(withIdentifier: "LynkConfigViewController") as! LynkConfigViewController
        lynkConfigViewController.centralDeviceID = newSystemData["lynk_central_id"]
        lynkConfigViewController.centralDevicePeripheral = newSystemData["lynk_central_peripheral_type"]
        lynkConfigViewController.remoteDeviceID = newSystemData["lynk_remote_id"]
        lynkConfigViewController.remoteDevicePeripheral = newSystemData["lynk_remote_peripheral_type"]
        lynkConfigViewController.customerID = newSystemData["customer_id"]
        lynkConfigViewController.zipCode = newSystemData["zip_code"]
        lynkConfigViewController.systemName = newSystemData["system_title"]
        self.navigationController?.pushViewController(lynkConfigViewController, animated: true)
    }
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if (identifier == "SelectSystemTypeSegue" && allowTypeSelect == false) {
            return false
        }
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let indexPath = self.tableView.indexPathForSelectedRow!
        
        if(segue.identifier=="SelectSystemTypeSegue") {
            let destinationVC = segue.destination as! SystemTypeTableViewController
            destinationVC.newSystemTableViewController = self
            
        }
        if(segue.identifier=="SelectDeviceSegue") {
            let destinationVC = segue.destination as! SelectDeviceViewController
            destinationVC.newSystemTableViewController = self
            if newSystemData["type"]=="lynk" {
                if indexPath.section==1 && indexPath.row==0 {
                    destinationVC.systemDeviceField = "lynk_central_id"
                }
                if indexPath.section==2 && indexPath.row==0 {
                    destinationVC.systemDeviceField = "lynk_remote_id"
                }
            }
        }
        if(segue.identifier=="SelectPeripheralTypeSegue") {
            let destinationVC = segue.destination as! SelectPeripheralTableViewController
            destinationVC.newSystemTableViewController = self
            if newSystemData["type"]=="lynk" {
                destinationVC.peripheralTypes = lynkPeripheals
                if indexPath.section==1 && indexPath.row==1 {
                    destinationVC.systemPeripheralField = "lynk_central_peripheral_type"
                }
                if indexPath.section==2 && indexPath.row==1 {
                    destinationVC.systemPeripheralField = "lynk_remote_peripheral_type"
                }
            }
        }
        
    }
    
    
}
