//
//  Util.swift
//  SureFi Config
//
//  Created by John Robinson on 10/21/16.
//  Copyright © 2016 Sure-Fi. All rights reserved.
//

import Foundation
import UIKit

class Util: NSObject {
    
    let apiURLString = "http://admin.sure-fi.com/mobile_api"
    let apiAccessKey = ""
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    func checkServerConnection() -> Bool {
     
        let networkStatus = Reachability().connectionStatus()
        switch networkStatus {
        case .Unknown, .Offline:
            return false
        case .Online(.WWAN):
            print("Connected via WWAN")
            return true
        case .Online(.WiFi):
            print("Connected via WiFi")
            return true
        }
    }
    
    func getServerRequest(action : String, apiData :String) ->NSMutableDictionary{
        
        var sessionKey = ""
        var userKey = ""
        if(appDelegate.sessionKey != nil && appDelegate.sessionKey != "") {
            sessionKey = appDelegate.sessionKey!
        }
        if(appDelegate.userKey != nil && appDelegate.userKey != "") {
            userKey = appDelegate.userKey!
        }
        
        let apiPath = "http://admin.sure-fi.com/mobile_api/\(action)/\(sessionKey)/\(userKey)/\(apiData)"
        if let apiURL = URL(string: apiPath)
        {
            if let apiData = try? Data(contentsOf: apiURL as URL) {
                do
                {
                    let parsedData = try JSONSerialization.jsonObject(with: apiData, options: JSONSerialization.ReadingOptions.mutableContainers)
                    let apiDictionary = parsedData as? NSDictionary
                    
                    return apiDictionary as! NSMutableDictionary
                }
                catch let error as NSError {
                    print("Details of JSON parsing error:\n \(error)")
                }
            }
        }
        return NSMutableDictionary()
    }
}

extension String {
    
    func fromBase64() -> String? {
        guard let data = Data(base64Encoded: self) else {
            return nil
        }
        
        return String(data: data, encoding: .utf8)
    }
    
    func toBase64() -> String {
        return Data(self.utf8).base64EncodedString()
    }
}
