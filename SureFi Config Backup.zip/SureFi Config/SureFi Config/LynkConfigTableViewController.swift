//
//  LynkConfigTableViewController.swift
//  SureFi Config
//
//  Created by John Robinson on 11/29/16.
//  Copyright © 2016 Sure-Fi. All rights reserved.
//

import UIKit
import CoreBluetooth

class LynkConfigTableViewController: UITableViewController, CBCentralManagerDelegate, CBPeripheralDelegate {
    
    var lynkSystemData :[String:String] = [:]
    
    var centralManager: CBCentralManager!
    var peripherals: Array<CBPeripheral> = Array<CBPeripheral>()
    var centralPeripheral: CBPeripheral!
    var remotePeripheral: CBPeripheral!
    var surefiDevices: Array<CBPeripheral> = Array<CBPeripheral>()
    
    var redCharactericCentral: CBCharacteristic!
    var greenCharactericCentral: CBCharacteristic!
    var blueCharactericCentral: CBCharacteristic!
    
    var redCharactericRemote: CBCharacteristic!
    var greenCharactericRemote: CBCharacteristic!
    var blueCharactericRemote: CBCharacteristic!
    
    
    var remoteFirmwareCharacteristic: CBCharacteristic!
    var centralFirmwareCharacteristic: CBCharacteristic!
    
    var centralRedValue : Float = 0;
    var centralGreenValue : Float = 0;
    var centralBlueValue : Float = 0;
    
    let BEAN_SERVICE_UUID       = CBUUID(string: "a495ff20-c5b1-4b44-b512-1370f02d74de")
    let BEAN_SCRATCH_UUIDR      = CBUUID(string: "a495ff21-c5b1-4b44-b512-1370f02d74de")
    let BEAN_SCRATCH_UUIDG      = CBUUID(string: "a495ff22-c5b1-4b44-b512-1370f02d74de")
    let BEAN_SCRATCH_UUIDB      = CBUUID(string: "a495ff23-c5b1-4b44-b512-1370f02d74de")
    let BEAN_SCRATCH_UUIDFIRM   = CBUUID(string: "a495ff24-c5b1-4b44-b512-1370f02d74de")
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backgroundImage = UIImage(named: "background");
        let backgroundImageView = UIImageView(image: backgroundImage);
        backgroundImageView.contentMode = UIViewContentMode.scaleAspectFill;
        self.tableView.backgroundView = backgroundImageView;
        
        let backItem = UIBarButtonItem()
        backItem.title = "Back"
        navigationItem.backBarButtonItem = backItem
        
        navigationItem.title = "Configure Sure-Fi Lynk"
        
        centralManager = CBCentralManager(delegate: self, queue: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        if (lynkSystemData["lynk_remote_id"]==nil || lynkSystemData["lynk_remote_id"]=="") {
            return 1
        }
        return 2
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            if (lynkSystemData["lynk_central_id"] != nil && lynkSystemData["lynk_central_id"] != "") {
                return 6
            }
        }
        return 1
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        if section == 0 {
            return "Lynk Central Unit"
        }
        else if section == 1 {
            return "Lynk Remote Unit"
        }
        return ""
    }
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let header: UITableViewHeaderFooterView = view as! UITableViewHeaderFooterView;
        header.textLabel?.textColor = UIColor.white;
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell : UITableViewCell!
        
        
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                cell = tableView.dequeueReusableCell(withIdentifier: "DeviceSelectCell", for: indexPath)
                
                var deviceImageView: UIImageView = cell.viewWithTag(100) as! UIImageView
                var deviceTitleLabel: UILabel = cell.viewWithTag(200) as! UILabel
                var deviceDescLabel: UILabel = cell.viewWithTag(300) as! UILabel
                
                deviceImageView.image = UIImage(named: "select_icon")
                deviceTitleLabel.text = "Select Cental Unit"
                deviceDescLabel.text = "Compatable Sure-Fi Lynk Device"
 
                if (lynkSystemData["lynk_central_id"] != nil && lynkSystemData["lynk_central_id"] != "")
                {
                    appDelegate.userKey = "12345678-1234-XXXX-XXXX-0123456789AB";
                    
                    let timestamp = Int(NSDate().timeIntervalSince1970)
                    let timestampstring = String(format:"%2X", timestamp)
                    let sessionKey = String("12345678\(timestampstring)".characters.reversed())
                    
                    appDelegate.sessionKey = sessionKey
                    
                    let results : NSMutableDictionary = Util().getServerRequest(action: "check_lynk_system", apiData: "\(lynkSystemData["lynk_central_id"]!)")
                    if results["status"] != nil && results["status"] as! String == "success" {
                        
                        deviceImageView.image = UIImage(named: "lynk_hardware_icon")
                        deviceTitleLabel.text = "Central Unit"
                        deviceDescLabel.text = lynkSystemData["lynk_central_id"]
                        
                        for device in surefiDevices {
                            if(device.identifier.uuidString == lynkSystemData["lynk_central_id"]) {
                                centralPeripheral = device
                                centralPeripheral.delegate = self
                                centralManager.connect(device, options: nil)
                            }
                        }
                    }
                    else if results["status"] as! String == "failure" {
                        let apiMessage = results["message"] as! String
                        let alert = UIAlertController(title: "Configuration Error", message: apiMessage, preferredStyle: .alert)
                        let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                        alert.addAction(ok)
                        self.present(alert, animated: true, completion: nil)
                        self.navigationItem.setHidesBackButton(false, animated: false)
                        lynkSystemData["lynk_central_id"] = ""
                        tableView.reloadData()
                    }
                }
            }
            if indexPath.row == 1 {
                cell = tableView.dequeueReusableCell(withIdentifier: "ColorSelectorCell", for: indexPath)
                let colorImageView: UIImageView = cell.viewWithTag(100) as! UIImageView
                let colorTitleLabel: UILabel = cell.viewWithTag(200) as! UILabel
                let colorSlider: UISlider = cell.viewWithTag(300) as! UISlider
                
                colorImageView.image = UIImage(named: "red_led_icon")
                colorTitleLabel.text = "Red LED"
                colorSlider.tintColor = UIColor.red
                colorSlider.maximumValue = 255
                colorSlider.minimumValue = 0
                colorSlider.isContinuous = false
                colorSlider.value = centralRedValue
                colorSlider.addTarget(self, action: #selector(setCentralRedValue), for: .valueChanged)
            }
            if indexPath.row == 2 {
                cell = tableView.dequeueReusableCell(withIdentifier: "ColorSelectorCell", for: indexPath)
                let colorImageView: UIImageView = cell.viewWithTag(100) as! UIImageView
                let colorTitleLabel: UILabel = cell.viewWithTag(200) as! UILabel
                let colorSlider: UISlider = cell.viewWithTag(300) as! UISlider
                
                colorImageView.image = UIImage(named: "green_led_icon")
                colorTitleLabel.text = "Green LED"
                colorSlider.tintColor = UIColor.green
                colorSlider.maximumValue = 255
                colorSlider.minimumValue = 0
                colorSlider.isContinuous = false
                colorSlider.value = centralGreenValue
                colorSlider.addTarget(self, action: #selector(setCentralGreenValue), for: .valueChanged)
            }
            if indexPath.row == 3 {
                cell = tableView.dequeueReusableCell(withIdentifier: "ColorSelectorCell", for: indexPath)
                let colorImageView: UIImageView = cell.viewWithTag(100) as! UIImageView
                let colorTitleLabel: UILabel = cell.viewWithTag(200) as! UILabel
                let colorSlider: UISlider = cell.viewWithTag(300) as! UISlider
                
                colorImageView.image = UIImage(named: "blue_led_icon")
                colorTitleLabel.text = "Blue LED"
                colorSlider.tintColor = UIColor.blue
                colorSlider.maximumValue = 255
                colorSlider.minimumValue = 0
                colorSlider.isContinuous = false
                colorSlider.value = centralBlueValue
                colorSlider.addTarget(self, action: #selector(setCentralBlueValue), for: .valueChanged)
            }
            if indexPath.row == 4 {
                cell = tableView.dequeueReusableCell(withIdentifier: "OptionCell", for: indexPath)
                let optionImageView: UIImageView = cell.viewWithTag(100) as! UIImageView
                let optionTitleLabel: UILabel = cell.viewWithTag(200) as! UILabel
                
                optionImageView.image = UIImage(named: "bluetooth_pairing_icon")
                optionTitleLabel.text = "Set Remote Lynk to Config Mode"
            }
            if indexPath.row == 5 {
                cell = tableView.dequeueReusableCell(withIdentifier: "OptionCell", for: indexPath)
                let optionImageView: UIImageView = cell.viewWithTag(100) as! UIImageView
                let optionTitleLabel: UILabel = cell.viewWithTag(200) as! UILabel
                
                optionImageView.image = UIImage(named: "firmware_update_icon")
                optionTitleLabel.text = "Check for Firmware Update"
            }
        }
        if(indexPath.section==1) {
            
            cell = tableView.dequeueReusableCell(withIdentifier: "DeviceSelectCell", for: indexPath)
            let deviceImageView: UIImageView = cell.viewWithTag(100) as! UIImageView
            let deviceTitleLabel: UILabel = cell.viewWithTag(200) as! UILabel
            let deviceDescLabel: UILabel = cell.viewWithTag(300) as! UILabel
            
            if indexPath.row == 0 {
                if (lynkSystemData["lynk_remote_id"]==nil || lynkSystemData["lynk_remote_id"]=="") {
                    deviceImageView.image = UIImage(named: "select_icon")
                    deviceTitleLabel.text = "Select Remote Unit"
                    deviceDescLabel.text = "Compatable Sure-Fi Lynk Device"
                }
                else {
                    deviceImageView.image = UIImage(named: "lynk_hardware_icon")
                    deviceTitleLabel.text = "Remote Unit"
                    deviceDescLabel.text = lynkSystemData["lynk_remote_id"]
                }
            }
        }
        return cell
    }
    
    func setSystemDataValue( field: String, value: String) {
        lynkSystemData[field] = value
    }
    
    func setCentralRedValue(slider: UISlider) {
        print("Setting Central Red Value:\(slider.value)")
        
        if(centralPeripheral != nil && redCharactericCentral != nil) {
            var data: [UInt8]! = [1]
            data[0] = UInt8.init(Int(slider.value))
            centralPeripheral.writeValue(Data(bytes:data), for: redCharactericCentral, type: CBCharacteristicWriteType.withResponse)
            centralRedValue = Float(Int(slider.value))
        }
    }
    
    func setCentralGreenValue(slider: UISlider) {
        print("Setting Central Green Value:\(slider.value)")
        
        if(centralPeripheral != nil && greenCharactericCentral != nil) {
            var data: [UInt8]! = [1]
            data[0] = UInt8.init(Int(slider.value))
            centralPeripheral.writeValue(Data(bytes:data), for: greenCharactericCentral, type: CBCharacteristicWriteType.withResponse)
            centralGreenValue = Float(Int(slider.value))
        }
    }
    
    func setCentralBlueValue(slider: UISlider) {
        print("Setting Central Blue Value:\(slider.value)")
        
        if(centralPeripheral != nil && blueCharactericCentral != nil) {
            var data: [UInt8]! = [1]
            data[0] = UInt8.init(Int(slider.value))
            centralPeripheral.writeValue(Data(bytes:data), for: blueCharactericCentral, type: CBCharacteristicWriteType.withResponse)
            centralBlueValue = Float(Int(slider.value))
        }
    }
    
    func setRemoteRedValue(slider: UISlider) {
        
    }
    
    func setRemoteGreenValue(slider: UISlider) {
        
    }
    
    func setRemoteBlueValue(slider: UISlider) {
        
    }
    
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let indexPath = self.tableView.indexPathForSelectedRow!
        
        if(segue.identifier=="SelectDeviceSegue") {
            let destinationVC = segue.destination as! SelectDeviceViewController
            destinationVC.lynkConfigTableViewController = self
            if indexPath.section==0 {
                destinationVC.systemDeviceField = "lynk_central_id"
            }
            if indexPath.section==1 {
                destinationVC.systemDeviceField = "lynk_remote_id"
            }
        }
        
    }
    
    func centralManagerDidUpdateState(_ central: CBCentralManager)
    {
        if (central.state == CBManagerState.poweredOn)
        {
            self.centralManager!.scanForPeripherals(withServices: nil, options: nil)
        }
        else
        {
            let alert: UIAlertController = UIAlertController(title: "Bluetooth Error", message: "Bluetooth is not turned on.", preferredStyle: UIAlertControllerStyle.alert);
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil));
            self.present(alert,animated: true, completion: nil);
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber)
    {
        let name = peripheral.name;
        if(name?.uppercased().range(of: "BEAN") != nil || name?.uppercased().range(of: "SUREFI") != nil) {
            if(!surefiDevices.contains(peripheral)) {
                surefiDevices.append(peripheral);
            }
        }
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        if centralPeripheral != nil && peripheral == centralPeripheral {
            centralPeripheral.discoverServices(nil)
        }
        if remotePeripheral != nil && peripheral == remotePeripheral {
            remotePeripheral.discoverServices(nil)
        }
        
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        for service in peripheral.services! {
            let thisService = service as CBService
            
            if service.uuid == BEAN_SERVICE_UUID {
                peripheral.discoverCharacteristics(nil,for: thisService)
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral,didDiscoverCharacteristicsFor service: CBService,error: Error?) {
        for characteristic in service.characteristics! {
            let thisCharacteristic = characteristic as CBCharacteristic
            
            
            if(centralPeripheral != nil && peripheral == centralPeripheral) {
                if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDFIRM {
                    peripheral.setNotifyValue(true,for: thisCharacteristic)
                    centralFirmwareCharacteristic = thisCharacteristic
                    print("Central Firmware Characteristic Found")
                }
                if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDR {
                    peripheral.setNotifyValue(true,for: thisCharacteristic)
                    redCharactericCentral = thisCharacteristic
                    print("Central Red Characteristic Found")
                }
                if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDG {
                    let data = thisCharacteristic.value
                    peripheral.setNotifyValue(true,for: thisCharacteristic)
                    greenCharactericCentral = thisCharacteristic
                    print("Central Green Characteristic Found")
                }
                if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDB {
                    peripheral.setNotifyValue(true,for: thisCharacteristic)
                    blueCharactericCentral = thisCharacteristic
                    print("Central Blue Characteristic Found")
                }
            }
            if(remotePeripheral != nil && peripheral == remotePeripheral) {
                if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDFIRM {
                    peripheral.setNotifyValue(true,for: thisCharacteristic)
                    remoteFirmwareCharacteristic = thisCharacteristic
                }
                if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDR {
                    peripheral.setNotifyValue(true,for: thisCharacteristic)
                    redCharactericRemote = thisCharacteristic
                }
                if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDG {
                    peripheral.setNotifyValue(true,for: thisCharacteristic)
                    greenCharactericRemote = thisCharacteristic
                }
                if thisCharacteristic.uuid == BEAN_SCRATCH_UUIDB {
                    peripheral.setNotifyValue(true,for: thisCharacteristic)
                    blueCharactericRemote = thisCharacteristic
                }
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        
        let value = characteristic.value! as Data
        let stringValue = NSString(data: value, encoding: String.Encoding.utf8.rawValue) as? String ?? ""
        let intValue = Int(value[0])
        
        if (centralPeripheral != nil && peripheral == centralPeripheral && characteristic==centralFirmwareCharacteristic) {
            //if stringValue == "ready" {
            //    //centralReady = true
            //}
        }
        if (remotePeripheral != nil && peripheral == remotePeripheral && characteristic==remoteFirmwareCharacteristic) {
            //if stringValue == "ready" {
            //    remoteReady = true
            //}
        }
        
        if(redCharactericCentral != nil && characteristic == redCharactericCentral) {
            
            let indexPath = IndexPath(row: 1, section: 0)
            if Float(intValue) != centralRedValue {
                centralRedValue = Float(intValue)
                print("Getting Central Red Value:\(intValue)")
                self.tableView.reloadRows(at: [indexPath], with: .none)
            }
        }
        if(redCharactericRemote != nil && characteristic == redCharactericRemote) {
            print("Remote Red:\(intValue)")
        }
        if(greenCharactericCentral != nil && characteristic == greenCharactericCentral) {
            let indexPath = IndexPath(row: 2, section: 0)
            if Float(intValue) != centralGreenValue {
                centralGreenValue = Float(intValue)
                print("Getting Central Green Value:\(intValue)")
                self.tableView.reloadRows(at: [indexPath], with: .none)
            }
        }
        if(greenCharactericRemote != nil && characteristic == greenCharactericRemote) {
            print("Remote Green:\(intValue)")
        }
        if(blueCharactericCentral != nil && characteristic == blueCharactericCentral) {
            let indexPath = IndexPath(row: 3, section: 0)
            if Float(intValue) != centralBlueValue {
                centralBlueValue = Float(intValue)
                print("Getting Central Blue Value:\(intValue)")
                self.tableView.reloadRows(at: [indexPath], with: .none)
            }
        }
        if(blueCharactericRemote != nil && characteristic == blueCharactericRemote) {
            print("Remote Blue:\(intValue)")
        }
    }
    
}
