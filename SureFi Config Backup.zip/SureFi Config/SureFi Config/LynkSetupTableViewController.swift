//
//  LynkSetupTableViewController.swift
//  SureFi Config
//
//  Created by John Robinson on 11/28/16.
//  Copyright © 2016 Sure-Fi. All rights reserved.
//

import UIKit

class LynkSetupTableViewController: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backgroundImage = UIImage(named: "background");
        let backgroundImageView = UIImageView(image: backgroundImage);
        backgroundImageView.contentMode = UIViewContentMode.scaleAspectFill;
        self.tableView.backgroundView = backgroundImageView;
        
        let logoImageView = UIImageView(image: UIImage(named: "sure-fi_menu"))
        self.navigationItem.titleView = logoImageView
        self.navigationItem.setHidesBackButton(true, animated:true);
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(section==1) {
            return 1
        }
        return 4
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0 {
            return "Sure-Fi Lynk Options"
        }
        return ""
    }
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let header: UITableViewHeaderFooterView = view as! UITableViewHeaderFooterView;
        header.textLabel?.textColor = UIColor.white;
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "OptionCell", for: indexPath)
        
        let tempImageView: UIImageView = cell.viewWithTag(100) as! UIImageView
        let tempTitleLabel: UILabel = cell.viewWithTag(200) as! UILabel
        
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                tempTitleLabel.text = "Setup New Lynk System"
                tempImageView.image = UIImage(named: "lynk_hardware_icon")
            }
            if indexPath.row == 1 {
                tempTitleLabel.text = "Configure Existing Lynk"
                tempImageView.image = UIImage(named: "settings_icon")
            }
            if indexPath.row == 2 {
                tempTitleLabel.text = "Troubleshoot Existing Lynk"
                tempImageView.image = UIImage(named: "troubleshooting_icon")
            }
            if indexPath.row == 3 {
                tempTitleLabel.text = "Manage Firmware Files"
                tempImageView.image = UIImage(named: "firmware_update_icon")
            }
        }
        if indexPath.section == 1 {
            if indexPath.row == 0 {
                tempTitleLabel.text = "Back to Welcome Screen"
                tempImageView.image = UIImage(named: "logout_icon_rev")
                cell.accessoryType = .none
            }
        }
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let newSystemTableViewController = storyboard.instantiateViewController(withIdentifier: "NewSystemTableViewController") as! NewSystemTableViewController
                newSystemTableViewController.allowTypeSelect = false
                newSystemTableViewController.newSystemData["type"] = "lynk"
                newSystemTableViewController.newSystemData["type_name"] = "Sure-Fi Lynk"
                newSystemTableViewController.newSystemData["customer_id"] = "XX"
                self.navigationController?.pushViewController(newSystemTableViewController, animated: true)
            }
            if indexPath.row == 1 {
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let lynkConfigTableViewController = storyboard.instantiateViewController(withIdentifier: "LynkConfigTableViewController") as! LynkConfigTableViewController
                self.navigationController?.pushViewController(lynkConfigTableViewController, animated: true)
            }
            if indexPath.row == 2 {
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let lynkTroubleshootingTableViewController = storyboard.instantiateViewController(withIdentifier: "LynkTroubleshootingTableViewController") as! LynkTroubleshootingTableViewController
                self.navigationController?.pushViewController(lynkTroubleshootingTableViewController, animated: true)
            }
            if indexPath.row == 3 {
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let lynkFirmwareTableViewController = storyboard.instantiateViewController(withIdentifier: "LynkFirmwareTableViewController") as! LynkFirmwareTableViewController
                self.navigationController?.pushViewController(lynkFirmwareTableViewController, animated: true)
            }
        }
        if indexPath.section == 1 {
            self.navigationController?.popViewController(animated: true)
        }
       
    }
    
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
